from django.urls import path
from . import views

urlpatterns = [
    path("getpartialkey/", views.get_partial_key, name="get-partial-key"),
    path("user-login/", views.user_login, name="user-login"),
    path("user-logout/", views.logout, name="logout"),
    path("user-info/", views.user_info, name="user-info"),
    path("entity_authentication/",views.entity_authentication,name="entity_authentication"),
    path("update_accumulator/",views.update_accumulator,name="update_accumulator"),
    path("receive_medical_data/",views.receive_medical_data,name="receive_medical_data"),
    path("entity-query/", views.entity_query, name="entity-query"),
    path("query-user/", views.query_user, name="query-user"),
    path("medical-query/", views.medical_data_query, name="medical-query"),
    path("entity-withdraw/", views.entity_withdraw, name="entity-withdraw"),
]
