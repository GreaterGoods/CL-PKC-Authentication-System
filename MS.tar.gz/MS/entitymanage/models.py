from django.db import models

# Create your models here.

#存储MS本身
class MSInfo(models.Model):
    ms_index = models.AutoField(primary_key=True, verbose_name="MS index")
    ms_pid = models.CharField(max_length=32, verbose_name="MS PID")
    ms_id = models.CharField(max_length=32, verbose_name="user id")
    ms_partialpub = models.TextField(verbose_name="MS Partial Pub", null=True)#R
    ms_wholepub = models.TextField(verbose_name="MS Whole Pub", null=True)#X
    ms_partialkey = models.TextField(verbose_name="MS Partial Key", null=True)#R
    ms_wholekey = models.TextField(verbose_name="MS Whole Key", null=True)#X
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")

    def get_data(self):
        return {
            "ms_pid": self.ms_pid,
            "ms_id": self.ms_id,
            "ms_partialkey": self.ms_partialkey,
            "ms_wholekey": self.ms_wholekey,
            "ms_partialpub": self.ms_partialpub,
            "ms_wholepub": self.ms_wholepub,
            "create_time": self.create_time,
        }
    
#存储用户信息以及与之挂钩的ME信息
class EntityInfo(models.Model):
    entity_index = models.AutoField(primary_key=True, verbose_name="entity index")
    entity_pid = models.CharField(max_length=32, verbose_name="entity pid")
    entity_fingerprint = models.TextField(verbose_name="entity fingerprint",null=True)#fingerprint
    ME_pid = models.CharField(max_length=32, verbose_name="ME pid",null=True)
    ME_ip = models.CharField(max_length=32, verbose_name="ME ip",null=True)
    ME_port = models.IntegerField(verbose_name="ME port",null=True)
    ME_partialpub = models.TextField(verbose_name="ME partial pub", null=True)#ME_R
    ME_wholepub = models.TextField(verbose_name="ME whole pub", null=True)#ME_X
    entity_partialpub = models.TextField(verbose_name="entity partial pub", null=True)#PE_R
    entity_wholepub = models.TextField(verbose_name="entity whole pub", null=True)#PE_X
    communication_key = models.BinaryField(verbose_name="communication key", null=True)#k
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")
    entity_witness = models.TextField(verbose_name="witness")#见证值
    is_alive = models.BooleanField(default=False, verbose_name="is alive")#是否存活

    def get_data(self):
        return {
            "entity_index": self.entity_index,
            "entity_pid": self.entity_pid,
            "entity_fingerprint": self.entity_fingerprint,
            "ME_pid": self.ME_pid,
            "ME_ip": self.ME_ip, 
            "ME_port": self.ME_port,
            "ME_partialpub": self.ME_partialpub,
            "ME_wholepub": self.ME_wholepub,
            "communication_key": self.communication_key.hex() if self.communication_key else None,
            "entity_partialpub": self.entity_partialpub,
            "entity_wholepub": self.entity_wholepub,
            "create_time": self.create_time,
            "entity_witness": self.entity_witness,
            "is_alive": self.is_alive,
       }

class UserTable(models.Model):
    user_id = models.CharField(max_length=32, primary_key=True, verbose_name="user id")
    user_pwd = models.CharField(max_length=20, verbose_name="user password")   
    user_name = models.CharField(max_length=20, verbose_name="user name")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")

    def get_data(self):
        return {
            "user_id": self.user_id,
            "user_name": self.user_name,
            "user_pwd": self.user_pwd,  
            "create_time": self.create_time,
        }

#存储医疗信息
class MedicalInfo(models.Model):
    medical_index = models.AutoField(primary_key=True, verbose_name="medical index")
    entity_pid = models.CharField(max_length=32, verbose_name="entity pid")
    ME_pid = models.CharField(max_length=32, verbose_name="ME pid")
    medical_data = models.TextField(verbose_name="medical data")#医疗信息
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")

    def get_data(self):
        return {
            "entity_pid": self.entity_pid,
            "ME_pid": self.ME_pid,
            "medical_data": self.medical_data,
            "create_time": self.create_time,
        }

class PublicParamtersTable(models.Model):
    kgc_id = models.CharField(max_length=32, primary_key=True,verbose_name="kgc_id")
    kgc_P = models.TextField(verbose_name="kgc P")
    kgc_Ppub = models.TextField(verbose_name="kgc_PpublicKey")
    kgc_q = models.TextField(verbose_name="kgc_q")
    kgc_acc_publickey = models.TextField(verbose_name="kgc acc public key")#p*q
    kgc_acc_cur = models.TextField(verbose_name="kgc acc cur")#累加值
    kgc_acc_serectkey0 = models.TextField(verbose_name="kgc acc serect key 0")#p
    kgc_acc_serectkey1 = models.TextField(verbose_name="kgc acc serect key 1")#q

'''sql初始数据
INSERT INTO `entitymanage_PublicParamtersTable` VALUES ('kgc_id','79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798|483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8','93b07eb082a7c58a1474302894ca31880d02a9ae7adbe102bcc25a58edc4e2e5|e28beb63378a2d4b8e2314b5733e52db5991a92ddf8acd4ff9b0a543ac41dbfd','fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141','a775863f0ad44ca20035dbc8bee624ec9d65415f670e0a7b501bffb6bb298c064d977c6f3a43728ca6a4eca0c35cf0a3957c007de7b601e4302738a734c3bd43','97ef1f09dcc6e81e2c08f3c96f04710fe1d05b39ac00e6fc190de20293c7ee01','f04fccdf714e91d01d7d87fbb12c8826ca0aad405aeab51f72c91dbcedbd5991','b2642d67ff49bb64d5de352ddf412a0681495550ad73799772de8648ddc4df93');
'''
