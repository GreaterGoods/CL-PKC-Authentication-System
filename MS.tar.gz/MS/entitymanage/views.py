from django.http import JsonResponse,HttpResponse
from django.shortcuts import render
from django.conf import settings
import json
from .models import *
import requests
from django.views.decorators.csrf import csrf_exempt
import time
import hashlib
import secrets
from commonutils import KGC
from commonutils import utils
from commonutils import accumulator
import psutil
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore,register_events,register_job
from fastecdsa import keys, point ,curve
import base64

# Create your views here.

acc = accumulator.Accumulator()
paramters_instance = PublicParamtersTable.objects.get(kgc_id="kgc_id")
P = utils.hex2point(paramters_instance.kgc_P)
Ppub = utils.hex2point(paramters_instance.kgc_Ppub)
q = utils.hex2int(paramters_instance.kgc_q)
MS_instance = MSInfo.objects.get(ms_id="ms_id")
acc.public_key = utils.hex2int(paramters_instance.kgc_acc_publickey)
acc.serect_key = (
    utils.hex2int(paramters_instance.kgc_acc_serectkey0),
    utils.hex2int(paramters_instance.kgc_acc_serectkey1),
)
acc.acc_cur = utils.hex2int(paramters_instance.kgc_acc_cur)
temps = EntityInfo.objects.filter(is_alive = True)
for temp in temps:
    acc.fingerprints.append(temp.entity_fingerprint)

AS_ip = settings.AS_IP
AS_port = settings.AS_PORT

scheduler = BackgroundScheduler(timezone='Asia/Shanghai')
scheduler.add_jobstore(DjangoJobStore(),"default")

def post_data(ip: str,port:int, path: str,payload: dict):
    try:
        header = {"content-type": "application/json","Connection":"close"}
        data = json.dumps(payload)
        url = "http://"+ip+":"+str(port)+path
        print(url)
        res = requests.post(url, data=data, headers=header)
        print(res.text)
    except Exception as e:
        print(e)

#登录
@csrf_exempt
def user_login(request):
    if request.method == "POST":
        try:
            # json_data = request.POST.get("login_form")
            print(request.META.get("REMOTE_ADDR"))
            json_data = json.loads(request.body.decode("utf-8"))
            user_name = json_data["username"]
            user_pwd = json_data["password"]
            user_instance = UserTable.objects.get(user_name=user_name)
            print(user_name)
            if user_instance == None:
                return JsonResponse({"status": "error", "message": "用户不存在"})
            if user_instance.user_pwd != user_pwd:
                return JsonResponse({"status": "error", "message": "密码错误"})
            else:
                user_id = user_instance.user_id
                # csrf_token = get_token(request)
                payload = {"token": user_id}
                return JsonResponse({"status": "success", "data": payload})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})


def logout(request):
    if request.method == "POST":
        return JsonResponse({"status": "success"})

@csrf_exempt
def user_info(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data)
            user_id = json_data["user_id"]
            print(user_id)
            user_instance = UserTable.objects.get(user_id=user_id)
            if user_instance == None:
                return JsonResponse({"status": "error", "message": "user not exist"})
            payload = {
                    "roles": ["admin"],
                    "introduction": "I am a super administrator",
                    "avatar": "https://upload.shejihz.com/2019/03/fe2ec2e7ed7f6795b46b793d93c99b7e.jpg",
                    "name": "管理员",
            }
            return JsonResponse({"status": "success", "data": payload})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#展示实体信息
@csrf_exempt
def entity_query(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            page = json_data["page"]
            limit = json_data["limit"]
            query_instance = EntityInfo.objects.all()
            length = query_instance.count()
            if length < page * limit:
                send_instance = query_instance[(page - 1) * limit : length]
            else:
                send_instance = query_instance[(page - 1) * limit : page * limit]
            data = {
                "num": send_instance.count(),
                "data": [temp.get_data() for temp in send_instance],
            }
            return JsonResponse({"status": "success", "message": data})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#显示MS信息
@csrf_exempt
def query_user(request):
    if request.method == "POST":
        try:
            list ={
                    "user_id": MS_instance.ms_id,
                    "user_pid": MS_instance.ms_pid,
                    "partialkey": MS_instance.ms_partialkey,
                    "partialpub": MS_instance.ms_partialpub,
                    "wholekey": MS_instance.ms_wholekey,
                    "wholepub": MS_instance.ms_wholepub,
                }
            return JsonResponse({"status": "success", "data": list})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#展示实体信息
@csrf_exempt
def entity_query(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            page = json_data["page"]
            limit = json_data["limit"]
            query_instance = EntityInfo.objects.all()
            length = query_instance.count()
            if length < page * limit:
                send_instance = query_instance[(page - 1) * limit : length]
            else:
                send_instance = query_instance[(page - 1) * limit : page * limit]
            data = {
                "num": send_instance.count(),
                "data": [temp.get_data() for temp in send_instance],
            }
            return JsonResponse({"status": "success", "message": data})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})#展示实体信息

#展示医疗信息
@csrf_exempt
def medical_data_query(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            page = json_data["page"]
            limit = json_data["limit"]
            query_instance = MedicalInfo.objects.all()
            length = query_instance.count()
            if length < page * limit:
                send_instance = query_instance[(page - 1) * limit : length]
            else:
                send_instance = query_instance[(page - 1) * limit : page * limit]
            data = {
                "num": send_instance.count(),
                "data": [temp.get_data() for temp in send_instance],
            }
            return JsonResponse({"status": "success", "message": data})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

"""与AS交互"""
# 获取传来的公共参数
def get_public_parameters(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data).get("data")
            pubparamter_instance = PublicParamtersTable.objects.get(
                kgc_id=json_data.get("kgc_id")
            )
            pubparamter_instance.kgc_acc_cur = json_data.get("acc_cur")
            pubparamter_instance.kgc_acc_publickey = json_data.get("acc_publickey")
            pubparamter_instance.kgc_q = json_data.get("kgc_q")
            pubparamter_instance.kgc_Ppub = json_data.get("kgc_Ppub")
            pubparamter_instance.save()
            return JsonResponse({"status": "success"})
        except Exception as e:
            print(e)
            return JsonResponse({"status": "error", "message": str(e)})

def save_kgc_parameters():
    paramters_instance = PublicParamtersTable.objects.get(kgc_id="kgc_id")
    paramters_instance.kgc_P = utils.point2hex(P)
    paramters_instance.kgc_Ppub = utils.point2hex(Ppub)
    paramters_instance.kgc_acc_publickey = acc.get_publickey()
    paramters_instance.kgc_acc_cur = acc.get_acc_cur()
    paramters_instance.kgc_acc_serectkey0 = acc.get_serect_key_0()
    paramters_instance.kgc_acc_serectkey1 = acc.get_serect_key_1()
    paramters_instance.save()

#更新累加器
@csrf_exempt
def update_accumulator(request):
    if request.method == "POST":
        try:
            data = request.body.decode("utf-8")
            data = json.loads(data).get("acc_data")
            pid = data["entity_pid"]
            new_acc = utils.hex2int(data["acc_cur"])
            print("new_acc:", new_acc)
            fingerprint = data["fingerprint"]
            witness = data["witness"]
            # 检查累加器更新是否正确：A_new = A_old^fingerprint mod N
            expected_acc = pow(acc.acc_cur, utils.hex2int(fingerprint), acc.public_key)
            print("expected_acc:", expected_acc)
            if new_acc != expected_acc:
                return JsonResponse({"status": "error", "message": "Invalid accumulator update"})
            else:
                print("accumulator update success")
            old_acc = acc.acc_cur
            acc.acc_cur = new_acc
            # 验证见证值是否正确
            print("fingerprint:",type(fingerprint))
            print("witness:",type(witness))
            print("public_key:", type(acc.public_key))
            if not acc.verify_member(fingerprint, witness):
                acc.acc_cur = old_acc
                return JsonResponse({"status": "error", "message": "Invalid witness"})
            else:
                print("witness verification success")
            entity_instance =EntityInfo.objects.filter(entity_pid=pid)
            if entity_instance.exists():
                entity_instance = EntityInfo.objects.get(entity_pid=pid)
                entity_instance.entity_fingerprint = fingerprint
                entity_instance.entity_witness = witness
                entity_instance.save()
                print("entity instance updated")
            else:
                entity_instance = EntityInfo()
                entity_instance.entity_pid = pid
                entity_instance.entity_fingerprint = fingerprint
                entity_instance.entity_witness = witness
                entity_instance.save()
                print("entity instance created")
            # 保存累加器状态
            save_kgc_parameters()
            print("save kgc parameters")
            acc.save_accumlator_parameters()
            print("save kgc parameters")
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

# 接收as发来的部分私钥和伪身份{"entity_data": {"entity_pid","d","R","user_id","create_time"}
@csrf_exempt
def get_partial_key(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data).get("entity_data")
            MS_instance = MSInfo.objects.get(ms_id = "ms_id")
            MS_instance.ms_pid = json_data["entity_pid"]
            d_hex = json_data["d"]
            d = utils.hex2int(d_hex)
            R_hex = json_data["R"]
            R = utils.hex2point(R_hex)
            create_time = json_data["create_time"]
            #判断dP ？= R + h1Ppub
            h1 = utils.calculate_h1(MS_instance.ms_pid, R, P, Ppub)
            dP = d * P
            h1Ppub = h1 * Ppub
            if(dP==R+h1Ppub):
                MS_instance.ms_partialkey = d_hex
                MS_instance.ms_partialpub = R_hex
                MS_instance.create_time = create_time
                MS_instance.ms_pid = json_data["entity_pid"]
                #生成完整公私钥
                x=secrets.randbelow(q - 1) + 1
                x_hex = utils.int2hex(x)
                X=x * P
                X_hex = utils.point2hex(X)
                MS_instance.ms_wholekey = x_hex
                MS_instance.ms_wholepub = X_hex
                MS_instance.save()
                return JsonResponse({"status": "success"})
            else:
                return JsonResponse({"status": "error", "message": "d*P != R + h1*Ppub"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
  
#接收ME发来的payload = {"message" : {"ME_data":{"entity_data"= "status": "requst","entity_ip","entity_port","create_time",},"entity_pid","partialpub","wholepub","timestamp","signature"},"fingerprint",}"ME_pid" ,"signature","partialpub" ,"wholepub" ,"ip","port","timestamp",}
@csrf_exempt
def entity_authentication(request):
    if request.method == "POST":
        try:
            # 获取请求体中的数据
            t2 = time.perf_counter()
            print(f"time2: {t2*1000:.3f}")
            json_data = json.loads(request.body.decode("utf-8"))
            ME_message = json_data["message"]
            ME_pid = json_data["ME_pid"]
            ME_signature = json_data["signature"]
            ME_R_hex = json_data["partialpub"]
            ME_X_hex = json_data["wholepub"]
            ME_ip = json_data.get("ip")
            ME_port = json_data.get("port")
            ME_timestamp = ME_signature.get("timestamp")
            # 验证ME签名
            if not verify_signature(ME_message, ME_pid, ME_R_hex, ME_X_hex, ME_timestamp, ME_signature):
                return JsonResponse({"status": "error", "message": "ME_signature verification failed"})
            else:
                print("ME_signature verification success")
            # 获取ME_message中的数据
            PE_data = ME_message["PE_data"]
            entity_data = PE_data.get("entity_data")
            fingerprint = ME_message["fingerprint"]#传过来的时候已经是hex
            PE_signature = PE_data["signature"]
            PE_pid = PE_data["entity_pid"]
            PE_R_hex = PE_data["partialpub"]
            PE_X_hex = PE_data["wholepub"]
            PE_timestamp = PE_signature["timestamp"]
            status = entity_data.get("status")
            #验证PE签名
            if not verify_signature(entity_data, PE_pid, PE_R_hex, PE_X_hex, PE_timestamp, PE_signature):
                return JsonResponse({"status": "error", "message": "PE_signature verification failed"})
            else:
                print("PE_signature verification succeeded")
            #请求认证
            if(status == "request"):
                #判断用户库是否存在该用户
                entity_pid = PE_data.get("entity_pid")
                entity_instance = EntityInfo.objects.filter(entity_pid = entity_pid).first()
                if entity_instance != None:
                    entity_instance = EntityInfo.objects.get(entity_pid = entity_pid)
                    if entity_instance.is_alive == True:
                            return JsonResponse({"status": "error", "message": "Entity already alive!"})                 
                    #验证指纹累加器
                    if acc.verify_member(fingerprint, entity_instance.entity_witness):
                        print("witness verification success")
                        entity_instance.entity_pid = entity_pid
                        entity_instance.entity_partialpub = PE_R_hex
                        entity_instance.entity_wholepub = PE_X_hex
                        entity_instance.entity_fingerprint = fingerprint
                        entity_instance.ME_pid = ME_pid
                        entity_instance.ME_ip = ME_ip
                        entity_instance.ME_port = ME_port 
                        entity_instance.ME_partialpub = ME_R_hex
                        entity_instance.ME_wholepub = ME_X_hex
                    else:
                        return JsonResponse({"status": "error", "message": "Witness verification failed!"})
                    #生成对称密钥
                    key_message = generate_key_message(ME_X_hex)
                    entity_instance.communication_key = key_message["key"]
                    MS_message = {
                        "K": key_message["K"],
                        "T": key_message["T"],
                    }
                    #签名
                    MS_signature = signature(MS_message, MS_instance.ms_pid)
                    payload = {
                        "message" : MS_message,
                        "MS_pid" : MS_instance.ms_pid,
                        "signature" : MS_signature,
                        "partialpub" : MS_instance.ms_partialpub,
                        "wholepub" : MS_instance.ms_wholepub,
                        "create_time" : int(time.time()),
                    }
                    t3 = time.perf_counter()
                    print(f"time3: {t3*1000:.3f}")
                    #发送给ME
                    response = post_to(
                        ME_ip, 
                        ME_port, 
                        "/entitymanage/receive-key/", 
                        payload)
                    if response and response.json()["status"] == "success":
                        #更新见证值
                        entity_instance.save()
                        print("entity instance updated")
                        users = EntityInfo.objects.filter(is_alive = True)
                        for user in users:
                            user.entity_witness = acc.update_witness(fingerprint, user.entity_witness)
                            user.save()
                        acc.fingerprints.append(fingerprint)
                        entity_instance.is_alive = True
                        entity_instance.save()
                        return JsonResponse({"status": "success", "message": "Entity data received successfully"})
                    else:
                        return JsonResponse({"status": "error", "message": response.json()["message"]})
                else :
                    return JsonResponse({"status": "error", "message": "Entity already exists"})    
            else:
                return JsonResponse({"status": "error", "message": "Unknown status!"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#接收医疗信息
@csrf_exempt
def receive_medical_data(request):
    if request.method == "POST":
        try:
            t2 = time.perf_counter()
            print(f"time2: {t2*1000:.3f}")
            json_data = json.loads(request.body.decode("utf-8"))
            m_b64 = json_data.get("medical_data")
            m = base64.b64decode(m_b64)
            entity_pid = json_data["entity_pid"]
            ME_pid = json_data["ME_pid"]
            timestamp = json_data["timestamp"]
            entity_instance = EntityInfo.objects.get(entity_pid = entity_pid)
            if entity_instance == None:
                return JsonResponse({"status": "error", "message": "Entity does not exist"})
            if entity_instance.ME_pid != ME_pid:
                return JsonResponse({"status": "error", "message": "ME_pid does not match"})
            medical_data = utils.decrypt_data(entity_instance.communication_key, m).decode("utf-8")
            t3 = time.perf_counter()
            print(f"time3: {t3*1000:.3f}")
            #保存医疗信息
            medical_instance = MedicalInfo()
            medical_instance.entity_pid = entity_pid
            medical_instance.ME_pid = ME_pid
            medical_instance.medical_data = medical_data
            medical_instance.save()
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})


#接收撤销请求
@csrf_exempt
def entity_withdraw(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            encrypted_data_b64 = json_data["data"]
            encrypted_data = base64.b64decode(encrypted_data_b64)
            entity_pid = json_data.get("entity_pid")
            ME_pid = json_data["ME_pid"]
            entity_instance = EntityInfo.objects.get(entity_pid = entity_pid)
            if entity_instance == None:
                return JsonResponse({"status": "error", "message": "Entity does not exist"})
            if entity_instance.ME_pid != ME_pid:
                return JsonResponse({"status": "error", "message": "ME_pid does not match"})
            decrypted_data = utils.decrypt_data(entity_instance.communication_key,encrypted_data)
            data = json.loads(decrypted_data.decode('utf-8'))
            entity_data = data.get("entity_data")
            if(entity_pid != data.get("entity_pid")):
                return JsonResponse({"status": "error", "message": "entity_pid does not match"})
            status = entity_data.get("status")
            if(status != "withdraw"):
                return JsonResponse({"status": "error", "message": "Unknown status!"})
            sign = data.get("signature")
            timestamp = sign.get("timestamp")
            # 验证签名
            if not verify_signature(entity_data, entity_pid, entity_instance.entity_partialpub, entity_instance.entity_wholepub, timestamp, sign):
                return JsonResponse({"status": "error", "message": "Signature verification failed"})
            #更新累加器
            aux = acc.remove_member(entity_instance.entity_fingerprint)
            # 通知AS同步
            payload = {
                "action": "DEL", 
                "pid": entity_instance.entity_pid,
                "aux": aux,}
            response = post_to(AS_ip, AS_port, "/usermanage/update_accumulator/", payload)
            if response and response.json()["status"] == "success":
                entity_instance.is_alive = False
                entity_instance.communication_key = None
                entity_instance.save()
                save_kgc_parameters()
                acc.save_accumlator_parameters()
                #更新见证值
                users = EntityInfo.objects.filter(is_alive = True)
                for user in users:
                    user.entity_witness = acc.update_witness(aux, user.entity_witness)
                    user.save()
                return JsonResponse({"status": "success"})
            else:
                acc.add_member(entity_instance.entity_fingerprint)
                return JsonResponse({"status": "error", "message": response.json()["message"]})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    
#验签
#signature = {"Y": str(Y), "w": w,  "timestamp": timestamp }
def verify_signature(data:dict, pid, partialpub:str, wholepub:str, timestamp, signature:dict):
    data_str = json.dumps(data, sort_keys=True)
    pid = str(pid)
    X = utils.hex2point(wholepub)
    R = utils.hex2point(partialpub)
    Ppubx = Ppub.x
    Ppuby = Ppub.y
    Rx = R.x
    Ry = R.y
    Y_hex = str(signature["Y"])
    #恢复Y的坐标
    Y = utils.hex2point(Y_hex)
    w = int(signature["w"])
    #ui = H2(mi, IDi,pki,ti,Yi)
    h2combined = f"2{data_str}{pid}{partialpub}{wholepub}{KGC.int2hex(timestamp)}{Y_hex}"
    u = int(hashlib.md5(h2combined.encode()).hexdigest(), 16)
    #h1i = H1(IDi,Ri,Ppub)
    h1combined = f"1{pid}{Rx}{Ry}{Ppubx}{Ppuby}"
    h1 = int(hashlib.md5(h1combined.encode()).hexdigest(), 16)
    #h3i = H3(mi,IDi,pki,ti)
    h3combined = f"3{data_str}{pid}{partialpub}{wholepub}{KGC.int2hex(timestamp)}"
    h3 = int(hashlib.md5(h3combined.encode()).hexdigest(), 16)
#验证下列等式:wiP – uiYi=h3i(Xi+Ri+h1iPpub)
    wP = w*P
    uY = u*Y
    h1Ppub = h1*Ppub
    temp = X + R + h1Ppub
    h3temp = h3*temp
    return (wP - uY) == h3temp

#签名
def signature(data: dict, pid: str):
    entity_instance = MSInfo.objects.get(ms_pid = pid)
    data_str = json.dumps(data, sort_keys=True)
    y=secrets.randbelow(q - 1) + 1
    Y = y * P
    Y_hex = utils.point2hex(Y)
    timestamp = int(time.time())
    #h3i = H3(mi,IDi,pki,ti)
    h3combined = f"3{data_str}{pid}{entity_instance.ms_partialpub}{entity_instance.ms_wholepub}{KGC.int2hex(timestamp)}"
    h3 = int(hashlib.md5(h3combined.encode()).hexdigest(), 16)
    #ui = H2(mi,IDi,pki,ti,Yi)
    h2combined = f"2{data_str}{pid}{entity_instance.ms_partialpub}{entity_instance.ms_wholepub}{KGC.int2hex(timestamp)}{Y_hex}"
    u = int(hashlib.md5(h2combined.encode()).hexdigest(), 16)
    #wi = uiyi + h3i(xi + di)(mod q);为int
    x =utils.hex2int(entity_instance.ms_wholekey)
    d = utils.hex2int(entity_instance.ms_partialkey)
    w = (u*y + h3*(x + d)) % q
    #将 mi||ti 的单个签名设置为 σi=(Yi,wi)
    signature = {
        "Y": Y_hex,  # 转换为字符串格式
        "w": w,
        "timestamp": timestamp,
    }
    return signature

#生成对称密钥
def generate_key_message(X_hex: str):
    X = utils.hex2point(X_hex)
    key = secrets.token_bytes(32)         # 256位随机密钥
    t = secrets.randbelow(q - 1) + 1
    T = t*P         # T = tP
    T_hex = utils.point2hex(T)
    tX = t*X        # tX = t*Xj
    tX_x_hex = hex(tX.x)[2:].zfill(64)    # x坐标转为64字符hex（补前导零）
    key_hex = key.hex()                   # 密钥转为64字符hex
    K = key_hex + tX_x_hex                # 固定128字符
    return {"K": K,
            "key": key,
            "T": T_hex}


'''
@csrf_exempt
# 接收as发来的撤销信息 {"withdrew_data":{"entity_pid":""}}
def get_withdraw_data(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data).get("withdraw_data")
            print("withdrew entity pid:"+json_data["entity_pid"])
            entity_instance = EntityInfo.objects.get(entity_pid = json_data["entity_pid"])
            entity_instance.delete()
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
'''        

#发送信息给ME
def post_to(entity_ip: str, entity_port: int, path: str, payload: dict):
    header = {"content-type": "application/json", "Connection": "close"}
    url = "http://" + entity_ip + ":" + str(entity_port) + path
    data = json.dumps(payload)
    try:
        res = requests.post(url, data=data, headers=header)
        print(res.status_code)
        return res
    except Exception as e:
        print(e)
        return None
