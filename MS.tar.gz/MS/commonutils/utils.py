from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from gmpy2 import next_prime
from fastecdsa import curve, keys, point
import secrets
import time
import os

def calculate_h1(pid: str, R: point.Point, Ppub: point.Point) -> int:
    #h1i = H1(IDi,Ri,Ppub)
    combined = f"{pid}{R.x}{R.y}{Ppub.x}{Ppub.y}"
    digest = hashes.Hash(hashes.MD5())
    digest.update(combined.encode())
    h1 = int.from_bytes(digest.finalize(), byteorder='big')
    return h1

def encrypt_data(key: bytes, plaintext: bytes) -> tuple:
    # 生成随机12字节的IV（GCM推荐长度）
    iv = os.urandom(12)
    # 创建加密器
    encryptor = Cipher(
        algorithms.AES(key),
        modes.GCM(iv),
        backend=default_backend()
    ).encryptor()
    # 加密数据
    ciphertext = encryptor.update(plaintext) + encryptor.finalize()
    # 返回IV + 密文 + 认证标签
    return iv + ciphertext + encryptor.tag

def decrypt_data(key: bytes, encrypted_data: bytes) -> bytes:
    # 拆分IV、密文、认证标签（IV:12字节，tag:16字节）
    iv = encrypted_data[:12]
    ciphertext = encrypted_data[12:-16]
    tag = encrypted_data[-16:]
    # 创建解密器
    decryptor = Cipher(
        algorithms.AES(key),
        modes.GCM(iv, tag),
        backend=default_backend()
    ).decryptor()
    # 解密数据
    plaintext = decryptor.update(ciphertext) + decryptor.finalize()
    return plaintext

def calculate_str_hash(std: str) -> str:
    tmp_hash = hashes.Hash(hashes.MD5())
    tmp_hash.update(std.encode())
    return tmp_hash.finalize().hex()


def hex2int(hex: str) -> int:
    """conver hex string to int"""
    return int(hex, 16)


def int2hex(num: int) -> str:
    """conver int to hex string"""
    return hex(num)[2:]


def get_bites(num: int, bits: int) -> str:
    """get bits of num"""
    return bin(num)[2:].zfill(bits)


def get_bits_length(num: int) -> int:
    """get bits length of num"""
    return len(get_bites(num, 128))


def point2hex(p: point.Point) -> str:
    """将椭圆曲线点序列化为 x|y 格式的十六进制字符串"""
    x_hex = int2hex(p.x)
    y_hex = int2hex(p.y)
    return f"{x_hex}|{y_hex}"

def hex2point(hex_str: str, curve=curve.secp256k1) -> point.Point:
    """从 x|y 格式的字符串恢复椭圆曲线点"""
    try:
        x_hex, y_hex = hex_str.split("|")
        x = int(x_hex, 16)
        y = int(y_hex, 16)
        p = point.Point(x, y, curve)
        if not curve.is_point_on_curve((x,y)):
            raise ValueError("点不在曲线上")
        return p
    except Exception as e:
        raise ValueError(f"无效的点格式: {e}")


def get_time_stamp() -> str:
    """get the current time stamp"""
    return str(int(time.time()))


def get_time_point() -> float:
    """get time point"""
    return time.perf_counter()


def get_duration(start: float, end: float) -> float:
    """
    Calculate the duration between two time points in milliseconds.

    Parameters:
    start_time (float): The start time in seconds.
    end_time (float): The end time in seconds.

    Returns:
    float: The duration between start_time and end_time in seconds.
    """

    return end - start


def get_os():
    if os.name =='nt':
        return "windows"
    elif os.name =='posix':
        return "linux"
    else:
        return "unknown"

def get_process_path(pid:int):
    try:
        # 判断当前系统
        if(get_os()=="windows"):
            import psutil
            process = psutil.Process(pid)
            return process.exe()
        elif(get_os()=="linux"):
            process_path=os.path.join("/proc",str(pid))
            exe_link = os.path.realpath(os.path.join(process_path, "exe"))    
            return exe_link
    except Exception as e:
        print(e)
        return None
if __name__ == "__main__":
    import os

    start = get_time_point()
    print(os.listdir())
    file_hash = calculate_file_hash("./manage.py")
    print(file_hash)
    print(hex2int(file_hash))
    print(int2hex(hex2int(file_hash)))
    print(get_bites(hex2int(file_hash), 64))
    print(get_bits_length(hex2int(file_hash)))
    print(get_duration(start, get_time_point()))
    print(secrets.token_hex(16))
    print(calculate_pid("bcd50201d588932dfc271f0489bbf823", "192.168.1.1"))
