import request from '@/utils/request'
const MODULE_BASE_URL = '/entitymanage'

export function getAllEntities() {
  return request({
    url: `/entitymanage/get_all_entities/`,
    method: 'get'
  })
}

export function SendMedicalData(data) {
  return request({
    url: `/entitymanage/send-medical-data/`,
    method: 'post',
    data
  })
}

export function login(data) {
  return request({
    url: `${MODULE_BASE_URL}/user-login/`,
    method: 'post',
    data
  })
}

export function getInfo(data) {
  return request({
    url: `${MODULE_BASE_URL}/user-info/`,
    method: 'post',
    data
  })
}

export function getUserInfo(token) {
  return request({
    url: `${MODULE_BASE_URL}/query-user/`,
    method: 'post',
    // params: { token }
    data: { user_id: token }
  })
}

export function logout() {
  return request({
    url: `${MODULE_BASE_URL}/user-logout/`,
    method: 'post'
  })
}

export function entityQuery(params) {
  return request({
    url: `${MODULE_BASE_URL}/entity-query/`,
    method: 'post',
    data: params
  })
}
