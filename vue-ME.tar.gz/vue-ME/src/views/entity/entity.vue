<template>
  <div>
    <div class="app-container">
      <el-table
        v-loading="listLoading"
        :data="userData ? [userData] : []"
        element-loading-text="Loading"
        border
        fit
        highlight-current-row
      >
        <el-table-column align="center" label="实体PID" width="130">
          <template slot-scope="scope">{{ scope.row.entity_pid }}</template>
        </el-table-column>
        <el-table-column align="center" label="部分公钥" width="130">
          <template slot-scope="scope">{{ scope.row.entity_partialpub }}</template>
        </el-table-column>
        <el-table-column align="center" label="部分公钥2" width="130">
          <template slot-scope="scope">{{ scope.row.entity_wholepub }}</template>
        </el-table-column>
        <el-table-column align="center" label="生成时间" width="130">
          <template slot-scope="scope">{{ scope.row.create_time }}</template>
        </el-table-column>
        <el-table-column align="center" label="通讯密钥" width="130">
          <template slot-scope="scope">{{ scope.row.communication_key }}</template>
        </el-table-column>
        <el-table-column
          align="center"
          fixed="right"
          label="操作"
          width="150"
        >
          <template slot-scope="scope">
            <el-button type="success" icon="el-icon-key" circle @click="handleSend(scope.row)" />
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import { entityQuery, SendMedicalData } from '@/api/entity'

export default {
  data() {
    return {
      userData: null,
      listLoading: true
    }
  },
  created() {
    this.getData()
  },
  methods: {
    // 获取实体信息
    getData() {
      this.listLoading = true
      entityQuery({ user_id: this.$store.state.user.id }).then((response) => {
        if (response.status === 'success') {
          this.userData = response.data
        } else {
          this.$message.error(response.message)
        }
        this.listLoading = false
      }).catch((err) => {
        this.$message.error(err)
        this.listLoading = false
      })
    },
    // 发送医疗信息
    handleSend(row) {
      this.$confirm('确定要发送医疗信息吗？', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        SendMedicalData({ entity_pid: row.entity_pid }).then(response => {
          if (response.status === 'success') {
            this.$message.success('发送成功！')
          } else {
            this.$message.error(response.message)
          }
        }).catch(() => {
          this.$message.error('发送失败，请稍后再试！')
        })
      }).catch(() => { })
    }
  }
}
</script>

<style lang="scss" scoped>
.app-container {
  margin-top: 20px;
}
</style>

