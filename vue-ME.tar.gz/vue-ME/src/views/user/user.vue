<template>
  <div>
    <div class="user-info">
      <h3>ME实体信息</h3>
      <el-card>
        <p>ID: {{ userInfo.user_id }}</p>
        <p>伪身份: {{ userInfo.user_pid }}</p>
        <p>部分密钥: {{ userInfo.partialkey }}</p>
        <p>部分公钥: {{ userInfo.partialpub }}</p>
        <p>部分密钥2: {{ userInfo.wholekey }}</p>
        <p>部分公钥2: {{ userInfo.wholepub }}</p>
      </el-card>
    </div>
  </div>
</template>

<script>
import { getUserInfo } from '@/api/entity'

export default {
  data() {
    return {
      userInfo: {}
    }
  },
  created() {
    this.fetchUserInfo()
  },
  methods: {
    fetchUserInfo() {
      const userId = this.$store.state.user.id
      console.log('Sending user ID:', userId)
      getUserInfo({ user_id: userId }).then((response) => {
        if (response.status === 'success') {
          this.userInfo = response.data
        } else {
          console.error('Error:', response.message) // Add error logging
        }
      })
    }
  }
}
</script>
