<template>
  <div>
    <div class="user-info">
      <h3>用户实体信息</h3>
      <el-card>
        <p>用户ID: {{ userInfo.user_id }}</p>
        <p>用户名: {{ userInfo.user_name }}</p>
        <p>伪身份: {{ userInfo.user_pid }}</p>
        <p>用户ip: {{ userInfo.user_ip }}</p>
        <p>用户端口: {{ userInfo.user_port }}</p>
        <p>部分密钥: {{ userInfo.partialkey }}</p>
        <p>部分公钥: {{ userInfo.partialpub }}</p>
        <p>部分密钥2: {{ userInfo.wholekey }}</p>
        <p>部分公钥2: {{ userInfo.wholepub }}</p>
      </el-card>
    </div>
  </div>
</template>

<script>
import { getUserInfo } from '@/api/entity'

export default {
  data() {
    return {
      userInfo: {}
    }
  },
  created() {
    this.fetchUserInfo()
  },
  methods: {
    fetchUserInfo() {
      const userId = this.$store.state.user.id
      getUserInfo({ user_id: userId }).then((response) => {
        if (response.status === 'success') {
          // 直接赋值整个data对象
          this.userInfo = response.data
        } else {
          console.error('获取用户信息失败:', response)
        }
      }).catch(error => {
        console.error('API请求错误:', error)
      })
    }
  }
}
</script>
