<template>
  <div>
    <div class="app-container">
      <el-table
        v-loading="listLoading"
        :data="list"
        element-loading-text="Loading"
        border
        fit
        highlight-current-row
      >
        <el-table-column align="center" prop="id" width="50" label="序号" />
        <el-table-column align="center" label="实体PID" width="130">
          <template slot-scope="scope">{{ scope.row.entity_pid }}</template>
        </el-table-column>
        <el-table-column align="center" label="所属IP" width="130">
          <template slot-scope="scope">{{ scope.row.entity_ip }}</template>
        </el-table-column>
        <el-table-column align="center" label="所属端口" width="130">
          <template slot-scope="scope">{{ scope.row.entity_port }}</template>
        </el-table-column>
        <el-table-column
          align="center"
          fixed="right"
          label="操作"
          width="150"
        >
          <template slot-scope="scope">
            <el-button type="success" icon="el-icon-key" circle @click="handleSend(scope.row)" />
            <el-button type="danger" icon="el-icon-delete" circle @click="handleWithdraw(scope.row)" />
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-container">
        <el-pagination
          :current-page="currentPage"
          :page-sizes="[5, 10, 15, 30, 50]"
          :page-size="pageSize"
          :layout="layout"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>

<script>
import { entityQuery, entitySend, entityWithdraw } from '@/api/entity'

export default {
  data() {
    return {
      list: null,
      listLoading: true,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      layout: 'total, prev, pager, next, sizes, jumper'
    }
  },
  created() {
    this.getData()
  },
  methods: {
    // 获取实体信息
    getData() {
      this.listLoading = true
      const params = {
        page: this.currentPage,
        limit: this.pageSize
      }
      entityQuery(params).then((response) => {
        this.list = response.message.data
        this.total = response.message.num
        const startId = (this.currentPage - 1) * this.pageSize + 1
        this.list = this.list.map((item, index) => {
          return {
            id: startId + index,
            ...item
          }
        })

        this.listLoading = false
      }).catch((err) => {
        console.error(err)
      })
    },
    // 发送实体信息
    handleSend(row) {
      this.$confirm('确定要发送信息吗？', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        entitySend({ entity_pid: row.entity_pid }).then(response => {
          if (response.status === 'success') {
            this.$message.success('发送成功！')
          } else {
            this.$message.error(response.message)
          }
        }).catch(() => {
          this.$message.error('发送失败，请稍后再试！')
        })
      }).catch(() => { })
    },
    // 撤销实体信息
    handleWithdraw(row) {
      this.$confirm('确定要撤销信息吗？', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        entityWithdraw({ entity_pid: row.entity_pid }).then(response => {
          if (response.status === 'success') {
            this.$message.success('撤销成功！')
            this.getData() // 刷新数据
          } else {
            this.$message.error(response.message)
          }
        }).catch(() => {
          this.$message.error('撤销失败，请稍后再试！')
        })
      }).catch(() => { })
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.currentPage = 1
      this.getData()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.getData()
    }
  }
}
</script>

<style lang="scss" scoped>
.pagination-container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 1%;
}
</style>
