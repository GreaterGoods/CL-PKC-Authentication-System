from django.db import models

# Create your models here.

class EntityInfo(models.Model):
    entity_index = models.AutoField(primary_key=True,verbose_name="entity_name")
    entity_pid = models.CharField(max_length=32, verbose_name="entity pid")
    user_id = models.CharField(max_length=32, verbose_name="user id")
    entity_partialkey = models.TextField(verbose_name="entity partial key", null=True)
    entity_wholekey = models.TextField(verbose_name="entity whole key", null=True)
    entity_partialpub = models.TextField(verbose_name="entity partial pub", null=True)
    entity_wholepub = models.TextField(verbose_name="entity whole pub", null=True)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")
    entity_ip = models.GenericIPAddressField(verbose_name="entity ip")
    entity_port = models.IntegerField(verbose_name="entity port")
    def get_data(self):
        return {
            "entity_index": self.entity_index,
            "entity_pid": self.entity_pid,
            "entity_partialkey": self.entity_partialkey,
            "entity_wholekey": self.entity_wholekey,
            "entity_partialpub": self.entity_partialpub,
            "entity_wholepub": self.entity_wholepub,
            "create_time": self.create_time,
            "entity_ip": self.entity_ip,
            "entity_port": self.entity_port,
       }


class UserTable(models.Model):
    user_id = models.CharField(max_length=32, primary_key=True, verbose_name="user id")
    user_pwd = models.CharField(max_length=20, verbose_name="user password")   
    user_name = models.CharField(max_length=20, verbose_name="user name")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")

    def get_data(self):
        return {
            "user_id": self.user_id,
            "user_name": self.user_name,
            "user_pwd": self.user_pwd,  
            "create_time": self.create_time,
        }


class PublicParamtersTable(models.Model):
    kgc_id = models.CharField(max_length=32, primary_key=True,verbose_name="kgc_id")
    kgc_q = models.TextField(verbose_name="kgc_q")
    kgc_Ppub = models.TextField(verbose_name="kgc_PpublicKey")
    kgc_P = models.TextField(verbose_name="kgc P")

'''kgc数据
INSERT INTO entitymanage_publicparamterstable VALUES ('kgc_id','fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141','93b07eb082a7c58a1474302894ca31880d02a9ae7adbe102bcc25a58edc4e2e5|e28beb63378a2d4b8e2314b5733e52db5991a92ddf8acd4ff9b0a543ac41dbfd','79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798|483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8');
'''