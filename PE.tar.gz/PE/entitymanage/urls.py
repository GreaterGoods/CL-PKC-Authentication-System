from django.urls import path
from . import views

urlpatterns = [
    path("getpartialkey/", views.get_partial_key, name="get-partial-key"),
    path("user-login/", views.user_login, name="user-login"),
    path("user-info/", views.user_info, name="user-info"),
    path("user-logout/", views.logout, name="logout"),
    path("query-user/", views.query_user, name="query-user"),
    path("send-entity/", views.send_entity, name="send-entity"),
    path("withdraw-entity/", views.withdraw_entity, name="withdraw-entity"),
    path("query-entity/", views.query_all, name="query-entity"),
]