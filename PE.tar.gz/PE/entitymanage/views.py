from django.http import JsonResponse,HttpResponse
from django.shortcuts import render
from django.conf import settings
import json
from .models import *
import requests
from django.views.decorators.csrf import csrf_exempt,get_token
import time
import secrets
from commonutils import KGC
from commonutils import utils
import psutil
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore,register_events,register_job
import hashlib
from fastecdsa import keys, point
# Create your views here.


paramters_instance = PublicParamtersTable.objects.get(kgc_id="kgc_id")
P = utils.hex2point(paramters_instance.kgc_P)
Ppub = utils.hex2point(paramters_instance.kgc_Ppub)
q = utils.hex2int(paramters_instance.kgc_q)
user_instance = UserTable.objects.get(user_id="user_id")


AS_ip = "192.168.3.17"
AS_port = "9527"

scheduler = BackgroundScheduler(timezone='Asia/Shanghai')
scheduler.add_jobstore(DjangoJobStore(),"default")


def send_csrf_token(request):
    csrf_token = get_token(request)
    return JsonResponse(data={"token": csrf_token})

def post_data(ip: str,port:int, path: str,payload: dict):
    try:
        header = {"content-type": "application/json","Connection":"close"}
        data = json.dumps(payload)
        url = "http://"+ip+":"+str(port)+path
        print(url)
        res = requests.post(url, data=data, headers=header)
        print(res.text)
    except Exception as e:
        print(e)


#登录
@csrf_exempt
def user_login(request):
    if request.method == "POST":
        try:
            print(request.META.get("REMOTE_ADDR"))
            json_data = json.loads(request.body.decode("utf-8"))
            user_name = json_data["username"]
            user_pwd = json_data["password"]
            user_instance = UserTable.objects.get(user_name=user_name)
            if user_instance == None:
                return JsonResponse({"status": "error", "message": "用户不存在"})
            if user_instance.user_pwd != user_pwd:
                return JsonResponse({"status": "error", "message": "密码错误"})
            else:
                user_id = user_instance.user_id
                payload = {"token": user_id}
                return JsonResponse({"status": "success", "data": payload})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

def logout(request):
    if request.method == "POST":
        return JsonResponse({"status": "success"})

@csrf_exempt
def user_info(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data)
            user_id = json_data["user_id"]
            print(user_id)
            user_instance = UserTable.objects.get(user_id=user_id)
            if user_instance == None:
                return JsonResponse({"status": "error", "message": "user not exist"})
            payload = {
                    "roles": ["editor"],
                    "introduction": "I am a patient",
                    "avatar": "https://upload.shejihz.com/2019/03/fe2ec2e7ed7f6795b46b793d93c99b7e.jpg",
                    "name": "用户",
                    "id": user_id,
            }
            return JsonResponse({"status": "success", "data": payload})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

"""与AS交互"""
# 获取传来的公共参数
def get_public_paramters(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data).get("data")
            pubparamter_instance = PublicParamtersTable.objects.get(
                kgc_id=json_data.get("kgc_id")
            )
            pubparamter_instance.acc_cur = json_data.get("acc_cur")
            pubparamter_instance.acc_publickey = json_data.get("acc_publickey")
            pubparamter_instance.kgc_q = json_data.get("kgc_q")
            pubparamter_instance.kgc_Ppub = json_data.get("kgc_Ppub")
            pubparamter_instance.save()
            return JsonResponse({"status": "success"})
        except Exception as e:
            print(e)
            return JsonResponse({"status": "error", "message": str(e)})

def save_kgc_paramters():
    paramters_instance = PublicParamtersTable.objects.get(kgc_id="kgc_id")
    paramters_instance.kgc_P = utils.point2hex(P)
    paramters_instance.kgc_q = utils.int2hex(paramters_instance.kgc_q)
    paramters_instance.kgc_Ppub = utils.point2hex(Ppub)
    paramters_instance.save()

# 接收as发来的部分私钥和伪身份{"entity_data": {"entity_pid","d","R","create_time"}
@csrf_exempt
def get_partial_key(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data).get("entity_data")
            # print(json_data)
            entity_instance = EntityInfo.objects.filter(user_id="user_id").first()
            if entity_instance != None:
                return JsonResponse({"status": "error", "message": "Entity exists!"})
            entity_instance = EntityInfo()
            entity_instance.entity_pid = json_data["entity_pid"]
            d_hex = json_data["d"]
            d = utils.hex2int(d_hex)
            R_hex = json_data["R"]
            R = utils.hex2point(R_hex)
            user_instance = UserTable.objects.filter().first()
            #判断dP ？= R + h1Ppub
            h1 = utils.calculate_h1(entity_instance.entity_pid, R, Ppub)
            dP = d*P
            h1Ppub = h1 * Ppub
            if(dP==R+h1Ppub):
                entity_instance.entity_partialkey = d_hex
                entity_instance.entity_partialpub = R_hex
                entity_instance.entity_pid = json_data["entity_pid"]
                entity_instance.user_id = user_instance.user_id
                entity_instance.entity_ip = json_data["entity_ip"]
                entity_instance.entity_port = json_data["entity_port"]
                #生成完整公私钥
                x=secrets.randbelow(q - 1) + 1
                x_hex = utils.int2hex(x)
                X=x * P
                X_hex = utils.point2hex(X)
                entity_instance.entity_wholekey = x_hex
                entity_instance.entity_wholepub = X_hex
                entity_instance.save()
                return JsonResponse({"status": "success"})
            else:
                return JsonResponse({"status": "error", "message": "d*P != R + h1*Ppub"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#显示所有实体
@csrf_exempt
def query_all(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            page = json_data["page"]
            limit = json_data["limit"]
            entities = EntityInfo.objects.exclude(user_id="user_id")
            length = entities.count()
            if length < page * limit:
                send_instance = entities[(page - 1) * limit : length]
            else:
                send_instance = entities[(page - 1) * limit : page * limit]
            data = {
                "num": send_instance.count(),
                "data": [temp.get_data() for temp in send_instance],
            }
            return JsonResponse({"status": "success", "message": data})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#显示用户信息
@csrf_exempt
def query_user(request):
    if request.method == "POST":
        try:
            user = UserTable.objects.get(user_id=user_instance.user_id)
            entity = EntityInfo.objects.get(user_id=user_instance.user_id)
            user_list ={
                    "user_id": user.user_id,
                    "user_name": user.user_name,
                    "user_pid": entity.entity_pid,
                    "user_ip": entity.entity_ip,
                    "user_port": entity.entity_port,
                    "partialkey": entity.entity_partialkey,
                    "partialpub": entity.entity_partialpub,
                    "wholekey": entity.entity_wholekey,
                    "wholepub": entity.entity_wholepub,
                }
            return JsonResponse({"status": "success", "data": user_list})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

# 发送实体信息       
@csrf_exempt
def send_entity(request):
    if request.method == "POST":
        try:
            tp = time.perf_counter()
            print(f"time0: {tp*1000:.3f}")
            json_data = json.loads(request.body.decode("utf-8"))
            entity_pid = json_data.get("entity_pid")
            # 获取实体信息
            ME_instance = EntityInfo.objects.filter(entity_pid=entity_pid).first()
            if ME_instance == None:
                return JsonResponse({"status": "error", "message": "ME Entity don't exists!"})
            entity_instance = EntityInfo.objects.filter(user_id=user_instance.user_id).first()
            if entity_instance == None:
                return JsonResponse({"status": "error", "message": "PE Entity don't exists!"})
            entity_data = {
                    "status": "request",
            }
            sign = signature(entity_data, entity_instance.entity_pid)
            payload = {#包含数据信息、用户实体的伪身份、公钥、时间戳、签名
                "entity_data": entity_data,
                "entity_pid": entity_instance.entity_pid,
                "partialpub": entity_instance.entity_partialpub,
                "wholepub": entity_instance.entity_wholepub,
                "timestamp": int(time.time()),
                "signature": sign,
            }
            # 发送数据到 ME
            t0 = time.perf_counter()
            print(f"time: {t0*1000:.3f}")
            response = post_to_ME(
                ME_instance.entity_ip,
                ME_instance.entity_port, 
                "/entitymanage/get_entity_data/", 
                payload)
            if response and response.json()["status"] == "success":
                return JsonResponse({"status": "success", "message": f"实体 {entity_pid} 已发送"})
            else:
                return JsonResponse({"status": "error",  "message": response.json()["message"]})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#发送撤销信息        
@csrf_exempt
def withdraw_entity(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            entity_pid = json_data.get("entity_pid")
            # 获取实体信息
            ME_instance = EntityInfo.objects.filter(entity_pid=entity_pid).first()
            if ME_instance == None:
                return JsonResponse({"status": "error", "message": "ME Entity don't exists!"})
            entity_instance = EntityInfo.objects.filter(user_id=user_instance.user_id).first()
            if entity_instance == None:
                return JsonResponse({"status": "error", "message": "PE Entity don't exists!"})
            entity_data = {
                    "status": "withdraw",
            }
            sign = signature(entity_data, entity_instance.entity_pid)
            payload = {#包含数据信息、用户实体的伪身份、公钥、时间戳、签名
                "entity_data": entity_data,
                "entity_pid": entity_instance.entity_pid,
                "partialpub": entity_instance.entity_partialpub,
                "wholepub": entity_instance.entity_wholepub,
                "timestamp": int(time.time()),
                "signature": sign,
            }
            # 发送数据到 ME
            response = post_to_ME(
                ME_instance.entity_ip,
                ME_instance.entity_port, 
                "/entitymanage/get_entity_data/", 
                payload)
            if response and response.json()["status"] == "success":
                #删除实体
                entity_instance.delete()
                return JsonResponse({"status": "success", "message": f"实体 {entity_pid} 已撤销"})
            else:
                return JsonResponse({"status": "error",  "message": response.json()["message"]})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#发送信息给ME
def post_to_ME(entity_ip: str, entity_port: int, path: str, payload: dict):
    header = {"content-type": "application/json", "Connection": "close"}
    url = "http://" + entity_ip + ":" + str(entity_port) + path
    data = json.dumps(payload)
    try:
        res = requests.post(url, data=data, headers=header)
        print(res.status_code)
        return res
    except Exception as e:
        print(e)
        return None


def get_user_id_from_request(request):
    try:
        # 从 Session 中获取用户 ID
        user_id = request.session.get("user_id")
        if not user_id:
            raise Exception("用户未登录")
        return user_id
    except Exception as e:
        raise Exception("无法获取用户 ID")
#签名
def signature(data: dict, pid: str):
    entity_instance = EntityInfo.objects.get(entity_pid = pid)
    data_str = json.dumps(data, sort_keys=True)
    y=secrets.randbelow(q - 1) + 1
    Y = y * P
    Y_hex = utils.point2hex(Y)
    timestamp = int(time.time())
    #h3i = H3(mi,IDi,pki,ti)
    h3combined = f"3{data_str}{pid}{entity_instance.entity_partialpub}{entity_instance.entity_wholepub}{KGC.int2hex(timestamp)}"
    h3 = int(hashlib.md5(h3combined.encode()).hexdigest(), 16)
    #ui = H2(mi,IDi,pki,ti,Yi)
    h2combined = f"2{data_str}{pid}{entity_instance.entity_partialpub}{entity_instance.entity_wholepub}{KGC.int2hex(timestamp)}{Y_hex}"
    u = int(hashlib.md5(h2combined.encode()).hexdigest(), 16)
    #wi = uiyi + h3i(xi + di)(mod q);为int
    x =utils.hex2int(entity_instance.entity_wholekey)
    d = utils.hex2int(entity_instance.entity_partialkey)
    w = (u*y + h3*(x + d)) % q
    #将 mi||ti 的单个签名设置为 σi=(Yi,wi)
    signature = {
        "Y": Y_hex,  # 转换为字符串格式
        "w": w,
        "timestamp": timestamp,
    }
    return signature



        
