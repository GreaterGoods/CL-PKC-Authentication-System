<template> 
  <div>
    <div class="app-container">
      <el-table
        v-loading="listLoading"
        :data="list"
        element-loading-text="Loading"
        border
        fit
        highlight-current-row
      >
        <el-table-column align="center" prop="id" width="50" label="序号" />
        <el-table-column align="center" label="用户伪身份" width="130">
          <template slot-scope="scope">{{ scope.row.entity_pid }}</template>
        </el-table-column>
        <el-table-column label="用户指纹" width="150" align="center">
          <template slot-scope="scope">
            <span>{{ scope.row.entity_fingerprint }}</span>
          </template>
        </el-table-column>
        <el-table-column label="医疗设备伪身份" width="130" align="center">
          <template slot-scope="scope">
            <span>{{ scope.row.ME_pid }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="医疗设备ip">
          <template slot-scope="scope">{{ scope.row.ME_ip }}</template>
        </el-table-column>
        <el-table-column align="center" label="医疗设备端口">
          <template slot-scope="scope">{{ scope.row.ME_port }}</template>
        </el-table-column>
        <el-table-column align="center" prop="created_time" label="创建时间">
          <template slot-scope="scope">
            <i class="el-icon-time" />
            <span>{{ scope.row.create_time }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="是否活跃">
          <template slot-scope="scope">
            {{ scope.row.is_alive ? '是' : '否' }}
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-container">
        <el-pagination
          :current-page="currentPage"
          :page-sizes="[5, 10, 15, 30, 50]"
          :page-size="pageSize"
          :layout="layout"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>

<script>
import { entityQuery } from '@/api/entity'

export default {
  data() {
    return {
      formLabelWidth: '100px',
      drawerLoading: false,
      drawerVisible: false,
      drawerTitle: '',
      list: null,
      listLoading: true,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      layout: 'total, prev, pager, next, sizes, jumper'
    }
  },
  created() {
    this.getData()
  },
  methods:{
    handleSizeChange(val) {
      this.pageSize = val
      this.currentPage = 1
      this.getData()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.getData()
    },
    getData() {
      this.listLoading = true
      const params = {
        page: this.currentPage,
        limit: this.pageSize
      }
      entityQuery(params).then((response) => {
        this.list = response.message.data
        this.total = response.message.num
        const startId = (this.currentPage - 1) * this.pageSize + 1
        this.list = this.list.map((item, index) => {
          return {
            id: startId + index,
            ...item
          }
        })

        this.listLoading = false
      }).catch((err) => {
        console.error(err)
      })
    },
  }
}
</script>

<style lang="scss" scoped>
.pagination-container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 1%;
}

.info-drawer__content {
  padding: 20px;
  height: 90%;
  overflow-y: auto;
}

.info-drawer__footer {
  padding: 20px;
  display: flex;
  justify-content: space-between, flex-end;
}

.info-drawer__footer .el-button:first-child {
  margin-left: auto;
  margin-right: 2%;
}
</style>
