<template>
  <div class="dashboard-container">
    <div class="dashboard-text">欢迎!  医疗人员</div>
  </div>
</template>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
