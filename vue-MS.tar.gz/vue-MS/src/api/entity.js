import request from '@/utils/request'

const MODULE_BASE_URL = '/entitymanage'


export function entityQuery(params) {
  return request({
    url: `${MODULE_BASE_URL}/entity-query/`,
    method: 'post',
    data: params
  })
}

export function entityQueryAlive(params) {
  return request({
    url: `${MODULE_BASE_URL}/entity-query-alive/`,
    method: 'post',
    data: params
  })
}

export function medicalQuery(params) {
  return request({
    url: `${MODULE_BASE_URL}/medical-query/`,
    method: 'post',
    data: params
  })
}

export function getUserInfo(token) {
  return request({
    url: `${MODULE_BASE_URL}/query-user/`,
    method: 'post',
    data: { user_id: token }
  })
}

export function login(data) {
  return request({
    url: `${MODULE_BASE_URL}/user-login/`,
    method: 'post',
    data
  })
}

export function getInfo(token) {
  return request({
    url: `${MODULE_BASE_URL}/user-info/`,
    method: 'post',
    data: { user_id: token }
  })
}

export function logout() {
  return request({
    url: `${MODULE_BASE_URL}/user-logout/`,
    method: 'post'
  })
}

export function userAdd(editedUser) {
  return request({
    url: `${MODULE_BASE_URL}/user-add/`,
    method: 'post',
    data: editedUser
  })
}
