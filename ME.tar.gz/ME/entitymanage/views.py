from django.http import JsonResponse,HttpResponse
from django.shortcuts import render
from django.conf import settings
import json
from .models import *
import requests
from django.views.decorators.csrf import csrf_exempt
import time
import hashlib
import secrets
from commonutils import KGC
from commonutils import utils
import psutil
from apscheduler.schedulers.background import BackgroundScheduler
from django_apscheduler.jobstores import DjangoJobStore,register_events,register_job
from fastecdsa import keys, point
import base64
# Create your views here.



paramters_instance = PublicParamtersTable.objects.get(kgc_id="kgc_id")
P = utils.hex2point(paramters_instance.kgc_P)
Ppub = utils.hex2point(paramters_instance.kgc_Ppub)
q = utils.hex2int(paramters_instance.kgc_q)
ME_instance = MEInfo.objects.get(me_id="me_id")


AS_ip = settings.AS_IP
AS_port = settings.AS_PORT
MS_ip = settings.MS_IP
MS_port = settings.MS_PORT

scheduler = BackgroundScheduler(timezone='Asia/Shanghai')
scheduler.add_jobstore(DjangoJobStore(),"default")

# def check_process_alive(processid:int):
#     try:
#         return psutil.pid_exists(processid)

#     except Exception as e:
#         return False

# bug fix: 修复活跃实体同步不到的问题，在调用时强转
def check_process_alive(processid):
    try:
        return psutil.pid_exists(processid)

    except Exception as e:
        print(e)
        return False
def post_data(ip: str,port:int, path: str,payload: dict):
    try:
        header = {"content-type": "application/json","Connection":"close"}
        data = json.dumps(payload)
        url = "http://"+ip+":"+str(port)+path
        print(url)
        res = requests.post(url, data=data, headers=header)
        print(res.text)
    except Exception as e:
        print(e)

#登录
@csrf_exempt
def user_login(request):
    if request.method == "POST":
        try:
            print(request.META.get("REMOTE_ADDR"))
            json_data = json.loads(request.body.decode("utf-8"))
            user_pwd = json_data["password"]
            if ME_instance == None:
                return JsonResponse({"status": "error", "message": "用户不存在"})
            if ME_instance.me_pwd != user_pwd:
                return JsonResponse({"status": "error", "message": "密码错误"})
            else:
                user_id = ME_instance.me_id
                payload = {"token": user_id}
                return JsonResponse({"status": "success", "data": payload})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

@csrf_exempt
def user_info(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data)
            user_id = json_data["user_id"]
            if ME_instance.me_id != user_id:
                return JsonResponse({"status": "error", "message": "user dismatch!"})
            payload = {
                    "roles": ["admin"],
                    "introduction": "I am a medical equipment",
                    "avatar": "https://upload.shejihz.com/2019/03/fe2ec2e7ed7f6795b46b793d93c99b7e.jpg",
                    "name": "用户",
                    "id": user_id,
            }
            return JsonResponse({"status": "success", "data": payload})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#显示ME信息
@csrf_exempt
def query_user(request):
    if request.method == "POST":
        try:
            list ={
                    "user_id": ME_instance.me_id,
                    "user_pid": ME_instance.me_pid,
                    "partialkey": ME_instance.me_partialkey,
                    "partialpub": ME_instance.me_partialpub,
                    "wholekey": ME_instance.me_wholekey,
                    "wholepub": ME_instance.me_wholepub,
                }
            return JsonResponse({"status": "success", "data": list})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#显示实体
@csrf_exempt
def query_entity(request):
    if request.method == "POST":
        try:
            entity_instance = EntityInfo.objects.filter().first()
            data = entity_instance.get_data()
            return JsonResponse({"status": "success", "data": data})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

"""与AS交互"""
# 获取传来的公共参数
def get_public_paramters(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data).get("data")
            pubparamter_instance = PublicParamtersTable.objects.get(
                kgc_id=json_data.get("kgc_id")
            )
            pubparamter_instance.kgc_q = json_data.get("kgc_q")
            pubparamter_instance.kgc_Ppub = json_data.get("kgc_Ppub")
            pubparamter_instance.save()
            return JsonResponse({"status": "success"})
        except Exception as e:
            print(e)
            return JsonResponse({"status": "error", "message": str(e)})

def save_kgc_paramters():
    paramters_instance = PublicParamtersTable.objects.get(kgc_id="kgc_id")
    paramters_instance.kgc_P = utils.point2hex(P)
    paramters_instance.kgc_q = utils.int2hex(paramters_instance.kgc_q)
    paramters_instance.kgc_Ppub = utils.point2hex(Ppub)
    paramters_instance.save()

# 接收as发来的部分私钥和伪身份{"entity_data": {"entity_pid","d","R","user_id","create_time"}
@csrf_exempt
def get_partial_key(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data).get("entity_data")
            ME_instance = MEInfo.objects.get(me_id = "me_id")
            ME_instance.me_pid = json_data["entity_pid"]
            d_hex = json_data["d"]
            d = utils.hex2int(d_hex)
            R_hex = json_data["R"]
            R = utils.hex2point(R_hex)
            #判断dP ？= R + h1Ppub
            h1 = utils.calculate_h1(ME_instance.me_pid, R, P, Ppub)
            dP = d*P
            h1Ppub = h1 * Ppub
            if(dP==R+h1Ppub):
                ME_instance.me_partialkey = d_hex
                ME_instance.me_partialpub = R_hex
                ME_instance.me_pid = json_data["entity_pid"]
                #生成完整公私钥
                x=secrets.randbelow(q - 1) + 1
                x_hex = utils.int2hex(x)
                X=x * P
                X_hex = utils.point2hex(X)
                ME_instance.me_wholekey = x_hex
                ME_instance.me_wholepub = X_hex
                ME_instance.save()
                return JsonResponse({"status": "success"})
            else:
                return JsonResponse({"status": "error", "message": "d*P != R + h1*Ppub"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
  
#接受PE发来的验证请求payload = {"entity_data"= {"status","entity_ip","entity_port","create_time"},"entity_pid","partialpub","wholepub","timestamp","signature",}
@csrf_exempt
def get_entity_data(request):
    if request.method == "POST":
        try:
            # 获取请求体中的数据
            t1 = time.perf_counter()
            print(f"time1: {t1*1000:.3f}")
            json_data = json.loads(request.body.decode("utf-8"))
            entity_data = json_data.get("entity_data")
            entity_pid = json_data.get("entity_pid")
            PE_R_hex = json_data.get("partialpub")
            PE_X_hex = json_data.get("wholepub")
            PE_signature = json_data["signature"]
            timestamp = PE_signature["timestamp"]
            status = entity_data.get("status")
            # 验证签名
            if not verify_signature(entity_data, entity_pid, PE_R_hex, PE_X_hex, timestamp, PE_signature):
                return JsonResponse({"status": "error", "message": "Signature verification failed"})
            else:
                print("Signature verification succeeded")
            #请求认证
            if(status == "request"):
                #判断用户库是否为空
                if EntityInfo.objects.count() == 0:
                    print("数据库为空，创建一个用户")
                    #数据库为空，创建一个用户
                    entity_instance = EntityInfo()
                    entity_instance.entity_pid = entity_pid
                    entity_instance.entity_partialpub = PE_R_hex
                    entity_instance.entity_wholepub = PE_X_hex
                    fingerprint = utils.get_prime_fingerprint("123456")
                    ME_message = {
                        "PE_data" : json_data,
                        "fingerprint": utils.int2hex(fingerprint),
                    }
                    #签名
                    ME_signature = signature(ME_message, ME_instance.me_pid)
                    t2 = time.perf_counter()
                    print(f"time2: {t2*1000:.3f}")
                    payload = {
                        "message" : ME_message,
                        "ME_pid" : ME_instance.me_pid,
                        "signature" : ME_signature,
                        "partialpub" : ME_instance.me_partialpub,
                        "wholepub" : ME_instance.me_wholepub,
                        "ip" : ME_instance.me_ip,
                        "port" : ME_instance.me_port,
                        "timestamp" : int(time.time()),
                    }
                    entity_instance.save()
                    #发送给MS
                    response = post_to_MS(
                        MS_ip, 
                        MS_port, 
                        "/entitymanage/entity_authentication/", 
                        payload)
                    if response and response.json()["status"] == "success":
                        return JsonResponse({"status": "success"})
                    else:
                        entity_instance.delete()
                        return JsonResponse({"status": "error", "message": response.json()["message"]})
                else :
                    return JsonResponse({"status": "error", "message": "Entity already exists"})  
            #处理撤销要求
            elif(status == "withdraw"):
                entity_instance = EntityInfo.objects.get()
                if entity_instance.entity_pid != entity_pid:
                    return JsonResponse({"status": "error", "message": "Entity error"}) 
                json_str = json.dumps(json_data)
                encrypted_data = utils.encrypt_data(entity_instance.communication_key, json_str.encode('utf-8'))
                encrypted_data_b64 = base64.b64encode(encrypted_data).decode('utf-8')
                payload = {
                    "data": encrypted_data_b64,
                    "entity_pid": entity_instance.entity_pid,
                    "ME_pid": ME_instance.me_pid,
                    "timestamp": int(time.time()),
                }
                response = post_to_MS(
                    MS_ip, 
                    MS_port, 
                    "/entitymanage/entity-withdraw/", 
                    payload)
                if response and response.json()["status"] == "success":
                    #直接清空用户库，反正只有一条数据
                    EntityInfo.objects.all().delete()
                    return JsonResponse({"status": "success"})
                else:
                    return JsonResponse({"status": "error", "message": response.json()["message"]})
            else:
                return JsonResponse({"status": "error", "message": "Unknown status!"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#接收 MS 发来的密钥信息
@csrf_exempt
def receive_key(request):
    if request.method == "POST":
        try:
            # 获取 MS 发来的密钥信息
            t5 = time.perf_counter()
            print(f"time2: {t5*1000:.3f}")
            json_data = json.loads(request.body.decode("utf-8"))
            MS_message = json_data.get("message")
            MS_pid = json_data.get("MS_pid")
            MS_signature = json_data.get("signature")
            MS_R_hex = json_data.get("partialpub")
            MS_X_hex = json_data.get("wholepub")
            MS_timestamp = MS_signature.get("timestamp")
            # 验证 MS 签名
            if not verify_signature(MS_message, MS_pid, MS_R_hex, MS_X_hex, MS_timestamp, MS_signature):
                return JsonResponse({"status": "error", "message": "MS_signature verification failed"})
            # 恢复密钥
            K = MS_message.get("K")
            T_hex = MS_message.get("T")
            x = ME_instance.me_wholekey 
            key = recover_key(K, T_hex, x)
            entity_instance = EntityInfo.objects.get()
            if MSInfo.objects.count() == 0:
                MS_instance = MSInfo()
                MS_instance.ms_pid = MS_pid
                MS_instance.ms_partialpub = MS_R_hex
                MS_instance.ms_wholepub = MS_X_hex
                MS_instance.save()
            else:
                MS_instance = MSInfo.objects.get(ms_pid = MS_pid)
                MS_instance.ms_partialpub = MS_R_hex
                MS_instance.ms_wholepub = MS_X_hex
                MS_instance.save()
            # 保存通信密钥
            entity_instance.communication_key = key
            entity_instance.save()
            print("通信密钥存储成功")
            return JsonResponse({"status": "success", "message": "Key received and processed successfully"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#发送医疗信息
@csrf_exempt
def send_medical_data(request):
    if request.method == "POST":
        try:
            if EntityInfo.objects.count() == 0:
                return JsonResponse({"status": "error", "message": "Entity does not exist"})
            #获取当前数据库信息
            t0 = time.perf_counter()
            print(f"time0: {t0*1000:.3f}")
            entity_instance = EntityInfo.objects.get()
            medical_message = "here is medical data"
            #加密
            m = utils.encrypt_data(entity_instance.communication_key, medical_message.encode('utf-8'))
            m_b64 = base64.b64encode(m).decode('utf-8')  # 先转base64，再转utf-8字符串
            payload = {
                "medical_data": m_b64,
                "entity_pid": entity_instance.entity_pid,
                "ME_pid": ME_instance.me_pid,
                "timestamp": int(time.time()),
            }
            t1 = time.perf_counter()
            print(f"time0: {t1*1000:.3f}")
            response = post_to_MS(
                MS_ip, 
                MS_port, 
                "/entitymanage/receive_medical_data/", 
                payload)
            if response and response.json()["status"] == "success":
                return JsonResponse({"status": "success"})
            else:
                return JsonResponse({"status": "error", "message": response.json()["message"]})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#验签
#signature = {"Y": str(Y), "w": w,  "timestamp": timestamp }
def verify_signature(data:dict, pid, partialpub:str, wholepub:str, timestamp, signature:dict):
    data_str = json.dumps(data, sort_keys=True)
    X = utils.hex2point(wholepub)
    R = utils.hex2point(partialpub)
    Ppubx = Ppub.x
    Ppuby = Ppub.y
    Rx = R.x
    Ry = R.y
    Y_hex = str(signature["Y"])
    #恢复Y的坐标
    Y = utils.hex2point(Y_hex)
    w = int(signature["w"])
    #ui = H2(mi, IDi,pki,ti,Yi)
    h2combined = f"2{data_str}{pid}{partialpub}{wholepub}{utils.int2hex(timestamp)}{Y_hex}"
    u = int(hashlib.md5(h2combined.encode()).hexdigest(), 16)
    #h1i = H1(IDi,Ri,Ppub)
    h1combined = f"1{pid}{Rx}{Ry}{Ppubx}{Ppuby}"
    h1 = int(hashlib.md5(h1combined.encode()).hexdigest(), 16)
    #h3i = H3(mi,IDi,pki,ti)
    h3combined = f"3{data_str}{pid}{partialpub}{wholepub}{utils.int2hex(timestamp)}"
    h3 = int(hashlib.md5(h3combined.encode()).hexdigest(), 16)
#验证下列等式:wiP – uiYi=h3i(Xi+Ri+h1iPpub)
    wP = w*P
    uY = u*Y
    h1Ppub = h1*Ppub
    temp = X + R + h1Ppub
    h3temp = h3*temp
    return (wP - uY) == h3temp

#签名
def signature(data: dict, pid: str):
    entity_instance = MEInfo.objects.get(me_pid = pid)
    data_str = json.dumps(data, sort_keys=True)
    #print("data_str:", data_str)
    y=secrets.randbelow(q - 1) + 1
    Y = y * P
    Y_hex = utils.point2hex(Y)
    timestamp = int(time.time())
    #h3i = H3(mi,IDi,pki,ti)
    h3combined = f"3{data_str}{pid}{entity_instance.me_partialpub}{entity_instance.me_wholepub}{KGC.int2hex(timestamp)}"
    h3 = int(hashlib.md5(h3combined.encode()).hexdigest(), 16)
    #ui = H2(mi,IDi,pki,ti,Yi)
    h2combined = f"2{data_str}{pid}{entity_instance.me_partialpub}{entity_instance.me_wholepub}{KGC.int2hex(timestamp)}{Y_hex}"
    u = int(hashlib.md5(h2combined.encode()).hexdigest(), 16)
    #wi = uiyi + h3i(xi + di)(mod q);为int
    x =utils.hex2int(entity_instance.me_wholekey)
    d = utils.hex2int(entity_instance.me_partialkey)
    w = (u*y + h3*(x + d)) % q
    #将 mi||ti 的单个签名设置为 σi=(Yi,wi)
    signature = {
        "Y": Y_hex,  # 转换为字符串格式
        "w": w,
        "timestamp": timestamp,
    }
    return signature

#恢复密钥
def recover_key(K: str, T_hex: str, x_hex: str):
    # 解析K
    x = utils.hex2int(x_hex)
    key_hex = K[:64]            # 前64字符为k
    tX_x_hex_received = K[64:]  # 后64字符为tX.x
    key = bytes.fromhex(key_hex)
    # 计算xj*T = xj*(tP) = t*(xjP) = tX
    T = utils.hex2point(T_hex)
    tX_calculated = x * T  # xj*T
    tX_x_calculated = hex(tX_calculated.x)[2:].zfill(64)
    # 验证tX.x是否一致
    if tX_x_hex_received != tX_x_calculated:
        raise ValueError("K被篡改")
    return key

'''
@csrf_exempt
# 接收as发来的撤销信息 {"withdrew_data":{"entity_pid":""}}
def get_withdraw_data(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data).get("withdraw_data")
            print("withdrew entity pid:"+json_data["entity_pid"])
            entity_instance = EntityInfo.objects.get(entity_pid = json_data["entity_pid"])
            entity_instance.delete()
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
'''        

#发送信息给MS
def post_to_MS(entity_ip: str, entity_port: int, path: str, payload: dict):
    header = {"content-type": "application/json", "Connection": "close"}
    url = "http://" + entity_ip + ":" + str(entity_port) + path
    data = json.dumps(payload)
    try:
        res = requests.post(url, data=data, headers=header)
        print(res.status_code)
        return res
    except Exception as e:
        print(e)
        return None
