from django.db import models

# Create your models here.

#存储ME本身和MS
class MSInfo(models.Model):
    ms_index = models.AutoField(primary_key=True, verbose_name="MS index")
    ms_pid = models.CharField(max_length=32, verbose_name="MS PID")
    ms_partialpub = models.TextField(verbose_name="MS Partial Pub", null=True)#R
    ms_wholepub = models.TextField(verbose_name="MS Whole Pub", null=True)#X
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")

    def get_data(self):
        return {
            "ms_pid": self.ms_pid,
            "ms_partialpub": self.ms_partialpub,
            "ms_wholepub": self.ms_wholepub,
            "create_time": self.create_time,
        }
    
class MEInfo(models.Model):
    me_id = models.CharField(max_length=32, primary_key=True, verbose_name="ME ID")
    me_pwd = models.CharField(max_length=20, verbose_name="me password")
    me_pid = models.CharField(max_length=32, verbose_name="ME PID",null=True)
    me_ip = models.GenericIPAddressField(verbose_name="entity ip")
    me_port = models.IntegerField(verbose_name="entity port")
    me_partialkey = models.TextField(verbose_name="ME Partial Key", null=True)#d
    me_wholekey = models.TextField(verbose_name="ME Whole Key", null=True)#x
    me_partialpub = models.TextField(verbose_name="ME Partial Pub", null=True)#R
    me_wholepub = models.TextField(verbose_name="ME Whole Pub", null=True)#X
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")

    def get_data(self):
        return {
            "me_id": self.me_id,
            "me_pid": self.me_pid,
            "me_ip": self.me_ip,
            "me_port": self.me_port,
            "me_partialkey": self.me_partialkey,
            "me_wholekey": self.me_wholekey,
            "me_partialpub": self.me_partialpub,
            "me_wholepub": self.me_wholepub,
            "create_time": self.create_time,
        }
    
#存储用户信息，只能存储一个用户
class EntityInfo(models.Model):
    entity_index = models.AutoField(primary_key=True, verbose_name="entity index")
    entity_pid = models.CharField(max_length=32, verbose_name="entity pid")
    communication_key = models.BinaryField(verbose_name="communication key", null=True)#k
    entity_partialpub = models.TextField(verbose_name="entity partial pub", null=True)#R
    entity_wholepub = models.TextField(verbose_name="entity whole pub", null=True)#X
    entity_fingerprint = models.TextField(max_length=20,verbose_name="entity fingerprint", null=True)#fingerprint
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")

    def get_data(self):
        return {
            "entity_index": self.entity_index,
            "entity_pid": self.entity_pid,
            "communication_key": self.communication_key.hex() if self.communication_key else None,
            "entity_partialpub": self.entity_partialpub,
            "entity_wholepub": self.entity_wholepub,
            "entity_fingerprint": self.entity_fingerprint,
            "create_time": self.create_time,
       }


class PublicParamtersTable(models.Model):
    kgc_id = models.CharField(max_length=32, primary_key=True,verbose_name="kgc_id")
    kgc_q = models.TextField(verbose_name="kgc_q")
    kgc_Ppub = models.TextField(verbose_name="kgc_PpublicKey")
    kgc_P = models.TextField(verbose_name="kgc P")
