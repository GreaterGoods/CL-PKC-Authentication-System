from django.urls import path
from . import views

urlpatterns = [
    path("getpartialkey/", views.get_partial_key, name="get-partial-key"),
    path("user-login/", views.user_login, name="user-login"),
    path("user-info/", views.user_info, name="user-info"),
    path("get_entity_data/", views.get_entity_data, name="get_entity_data"),
    path("receive-key/", views.receive_key, name="receive-key"),
    path("send-medical-data/", views.send_medical_data, name="send-medical-data"),
    path("query-user/", views.query_user, name="query-user"),
    path("entity-query/", views.query_entity, name="entity-query"),
]
