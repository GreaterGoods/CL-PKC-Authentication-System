<template>
  <div>
    <div class="app-container">
      <!-- 新增用户按钮 -->
      <el-button type="primary" icon="el-icon-plus" @click="handleAddUser" style="margin-bottom: 20px;">
        新增用户
      </el-button>

      <!-- 用户表单 -->
      <el-drawer
        class="info-drawer"
        :title="drawerTitle"
        :visible.sync="drawerVisible"
        direction="ltr"
        custom-class="info-drawer"
      >
        <div class="info-drawer__content">
          <el-form :model="editedUser" :rules="rules" ref="userForm" label-position="left">
            <el-form-item label="用户名" :label-width="formLabelWidth" required>
              <el-input v-model="editedUser.user_name" placeholder="请输入用户名" />
            </el-form-item>
            <el-form-item label="用户指纹" :label-width="formLabelWidth" required>
              <el-input v-model="editedUser.user_fingerprint" placeholder="请输入用户指纹" />
            </el-form-item>
            <el-form-item label="用户IP" :label-width="formLabelWidth" required>
              <el-input v-model="editedUser.user_ip" placeholder="请输入用户IP地址" />
            </el-form-item>
            <el-form-item label="用户端口号" :label-width="formLabelWidth" required>
              <el-input v-model="editedUser.user_port" placeholder="请输入用户端口号" />
            </el-form-item>
            <el-form-item label="用户手机号" :label-width="formLabelWidth">
              <el-input v-model="editedUser.user_phone" placeholder="请输入用户手机号" />
            </el-form-item>
          </el-form>
          <div class="info-drawer__footer">
            <el-button @click="handleDrawerClose">取消</el-button>
            <el-button type="primary" :loading="drawerLoading" @click="handleDrawerSubmit">
              {{ drawerLoading ? '提交中 ...' : '提交' }}
            </el-button>
          </div>
        </div>
      </el-drawer>
    </div>
  </div>
</template>
<script>

import { userAdd } from '@/api/user'

export default {
  data() {
    return {
      formLabelWidth: "100px",
      drawerLoading: false,
      drawerVisible: false,
      drawerTitle: "",
      editedUser: {
        user_name: "",
        user_fingerprint: "",
        user_ip: "",
        user_phone: "",
        user_port: "",
      },
      passwordType: "password",
      rules: {
        user_name: [{ required: true, message: "请输入用户名", trigger: "blur" }],
        user_ip: [{ required: true, message: "请输入用户IP地址", trigger: "blur" }],
        user_fingerprint: [{ required: true, message: "请输入用户指纹", trigger: "blur" }],
        user_port: [{ required: true, message: "请输入用户端口号", trigger: "blur" }],
      },
    };
  },
  methods: {
    handleAddUser() {
      this.drawerTitle = "新增用户";
      this.editedUser = {
        user_name: "",
        user_fingerprint: "",
        user_ip: "",
        user_phone: "",
        user_port: "",
      };
      this.drawerVisible = true;
    },
    handleDrawerSubmit() {
      this.$refs.userForm.validate((valid) => {
        if (!valid) return;
        this.drawerLoading = true;
        userAdd(this.editedUser)
          .then((response) => {
            if (response.status === "success") {
              this.$message.success("新增用户成功！");
              this.drawerVisible = false;
            } else {
              this.$message.error("新增用户失败！");
            }
          })
          .catch(() => {
            this.$message.error("新增用户失败，请稍后再试！");
          })
          .finally(() => {
            this.drawerLoading = false;
          });
      });
    },
    handleDrawerClose() {
      this.drawerVisible = false;
    },
  },
};
</script>
