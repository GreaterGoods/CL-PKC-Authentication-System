<template>
  <div>
    <div class="app-container">
      <el-table
        v-loading="listLoading"
        :data="list"
        element-loading-text="Loading"
        border
        fit
        highlight-current-row
      >
        <el-table-column align="center" prop="id" width="50" label="序号" />
        <el-table-column align="center" label="认证实体ID" width="130">
          <template slot-scope="scope">{{ scope.row.entity_pid }}</template>
        </el-table-column>
        <el-table-column align="center" label="所属用户ID" width="130">
          <template slot-scope="scope">{{ scope.row.user_id }}</template>
        </el-table-column>
        <el-table-column align="center" label="部署IP" width="130">
          <template slot-scope="scope">{{ scope.row.entity_ip }}</template>
        </el-table-column>
        <el-table-column align="center" label="部署端口" width="130">
          <template slot-scope="scope">{{ scope.row.entity_port }}</template>
        </el-table-column>
        <el-table-column align="center" label="部分私钥" width="95">
          <template slot-scope="scope">
            <el-tooltip class="description-tooltip" effect="dark" :content="scope.row.entity_parcialkey" :popper-options="{ boundariesElement: 'window' }" placement="top-start" :open-delay="500">
              <el-button
                type="primary"
                size="small"
                icon="el-icon-document-copy"
                @click="copyEntityParcialkey(scope.row.entity_pid, scope.row.entity_parcialkey)"
              >复制</el-button>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column class-name="status-col" label="活跃状态" width="95" align="center">
          <template slot-scope="scope">
            <el-tag :type="scope.row.is_alive | statusFilter">{{ scope.row.is_alive ? "运行中" : "未运行" }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="created_time" label="创建时间">
          <template slot-scope="scope">
            <i class="el-icon-time" />
            <span>{{ scope.row.create_time }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="update_time" label="更新时间">
          <template slot-scope="scope">
            <i class="el-icon-time" />
            <span>{{ scope.row.update_time }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-container">
        <el-pagination
          :current-page="currentPage"
          :page-sizes="[5, 10, 15, 30, 50]"
          :page-size="pageSize"
          :layout="layout"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>

<script>
import { entityQuery, entityQueryAlive } from '@/api/entity'
export default {
  filters: {
    statusFilter(status) {
      const statusMap = {
        'true': 'success',
        'false': 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      list: null,
      listLoading: true,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      layout: 'total, prev, pager, next, sizes, jumper',
      timer: null,
      timerInterval: 60000 // 轮询间隔：60s
    }
  },
  created() {
    this.getData()
    this.timer = setInterval(this.updateIsAlive, this.timerInterval)
  },
  beforeDestroy() {
    if (this.timer) {
      clearInterval(this.timer)
    }
  },
  methods: {
    copyEntityParcialkey(entityPid, entityParcialkey) {
      if (!entityParcialkey) {
        this.$message.error('部分私钥为空，请检查是否已为该认证实体下发密钥！')
        return
      }
      navigator.clipboard.writeText(entityParcialkey)
        .then(() => {
          this.$message.success(`已复制${entityPid}的部分私钥！`)
        })
        .catch(() => {
          this.$message.error('复制失败，请手动复制文本！')
        })
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.currentPage = 1
      this.getData()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.getData()
    },
    getData() {
      this.listLoading = true
      const params = {
        page: this.currentPage,
        limit: this.pageSize
      }
      entityQuery(params)
        .then((response) => {
          if (response && response.message) {
            this.list = response.message.data
            this.total = response.message.num

            const startId = (this.currentPage - 1) * this.pageSize + 1
            this.list = this.list.map((item, index) => {
              return {
                id: startId + index,
                ...item
              }
            })
          } else {
            this.$message.error('获取数据格式错误')
            this.list = []
            this.total = 0
          }
        })
        .catch((err) => {
          this.$message.error(err.message || '获取数据失败')
          this.list = []
          this.total = 0
        })
        .finally(() => {
          this.listLoading = false
        })
    },
    async updateIsAlive() {
      try {
        const params = {
          page: this.currentPage,
          limit: this.pageSize
        }
        const response = await entityQueryAlive(params)
        if (response && response.message) {
          this.list = response.message.data
          this.total = response.message.num

          const startId = (this.currentPage - 1) * this.pageSize + 1
          this.list = this.list.map((item, index) => {
            return {
              id: startId + index,
              ...item
            }
          })
        }
      } catch (err) {
        console.error('获取活跃实体失败:', err)
        // 不显示错误消息，因为这是定时任务
      } finally {
        this.listLoading = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.pagination-container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 1%;
}
</style>
