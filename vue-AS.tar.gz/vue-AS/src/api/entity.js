import request from '@/utils/request'

const MODULE_BASE_URL = '/entitymanage'


export function entityQuery(params) {
  return request({
    url: `${MODULE_BASE_URL}/query-entity-all/`,
    method: 'post',
    data: params
  })
}

export function entityQueryAlive(params) {
  return request({
    url: `${MODULE_BASE_URL}/entity-query-alive/`,
    method: 'post',
    data: params
  })
}

export function getUserInfo(params) {
  return request({
    url: `${MODULE_BASE_URL}/query-entity/`,
    method: 'post',
    data: params
  })
}
