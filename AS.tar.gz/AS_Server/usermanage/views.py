from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import json
from .models import *
from entitymanage.models import *
from commonutils.utils import *
from commonutils import kgc
from commonutils import accumulator
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt, get_token
import requests
import secrets
import gmpy2

def send_csrf_token(request):
    csrf_token = get_token(request)
    return JsonResponse(data={"token": csrf_token})

acc = accumulator.Accumulator()
kgc = kgc.KGC()
temp_params = KGCParamterTable.objects.get(kgc_id="kgc_id")
Ppub = hex2point(temp_params.kgc_Ppub)
P = hex2point(temp_params.kgc_P)
q = hex2int(temp_params.kgc_q)
s = hex2int(temp_params.kgc_s)
acc.public_key = hex2int(temp_params.kgc_acc_publickey)
acc.G = hex2int(temp_params.kgc_acc_G)
acc.serect_key = (
    hex2int(temp_params.kgc_acc_serectkey0),
    hex2int(temp_params.kgc_acc_serectkey1),
)
acc.acc_cur = hex2int(temp_params.kgc_acc_cur)

def kgc_paramter_save():
    kgc_instance = KGCParamterTable.objects.get(kgc_id="kgc_id")
    kgc_instance.kgc_acc_publickey = acc.get_publickey()
    kgc_instance.kgc_acc_cur = acc.get_acc_cur()
    kgc_instance.kgc_acc_serectkey0 = acc.get_serect_key_0()
    kgc_instance.kgc_acc_serectkey1 = acc.get_serect_key_1()
    kgc_instance.save()

#登录
@csrf_exempt
def user_login(request):
    if request.method == "POST":
        try:
            # json_data = request.POST.get("login_form")
            print(request.META.get("REMOTE_ADDR"))
            json_data = json.loads(request.body.decode("utf-8"))
            user_name = json_data["username"]
            user_pwd = json_data["password"]
            user_instance = ManagerTable.objects.get(manager_name=user_name)
            if user_instance == None:
                return JsonResponse({"status": "error", "message": "用户不存在"})
            if user_instance.manager_pwd != user_pwd:
                return JsonResponse({"status": "error", "message": "密码错误"})
            else:
                user_id = user_instance.manager_id
                payload = {"token": user_id}
                return JsonResponse({"status": "success", "data": payload})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#注册
@csrf_exempt
def user_add(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            if not json_data.get("user_ip") or not json_data.get("user_fingerprint"):
                return JsonResponse({"status": "error", "message": "IP地址和指纹信息为必填项"})          
            user_instance = UserTable()
            user_instance.user_id = calculate_str_hash(
                json_data["user_name"] + json_data["user_fingerprint"])
            if UserTable.objects.filter(user_id=user_instance.user_id).exists():
                user_instance = UserTable.objects.get(user_id=user_instance.user_id) 
            create_time = user_instance.create_time
            user_instance.create_time = create_time
            user_instance.user_name = json_data["user_name"]
            fingerprint = get_prime_fingerprint(json_data["user_fingerprint"])#确保素数
            user_instance.user_fingerprint = int2hex(fingerprint)
            user_instance.user_phone = json_data.get("user_phone", "")
            #计算pid、实体信息
            entity_instance = EntityTable()
            entity_instance.user_id = user_instance.user_id
            timestamp = time.time()
            timestamp = str(int(timestamp))
            #随机数r
            r = secrets.randbelow(q - 1) + 1
            R = r * P
            R_hex = point2hex(R)
            entity_pid = calculate_pid(user_instance.user_id, timestamp,r,temp_params.kgc_Ppub)
            print("pid:",entity_pid)
            if not entity_pid:
                return JsonResponse({"status": "error", "message": "生成实体PID失败"})
            entity_instance.entity_pid = entity_pid
            entity_instance.entity_ip = json_data["user_ip"]
            entity_instance.entity_port = json_data["user_port"]
            d = PartialKeyGen(entity_instance.entity_pid, r, R, P, Ppub,q,s)
            d_hex = int2hex(d)   
            entity_instance.entity_partialkey = d_hex
            # 发送对应的ME，如果未在线就退出
            payload = {
                "entity_data": {
                    "entity_pid": entity_instance.entity_pid,
                    "d": d_hex,
                    "R": R_hex,
                    "entity_ip": entity_instance.entity_ip,
                    "entity_port": entity_instance.entity_port,
                }
            }
            response = post_to_PE(
                entity_instance.entity_ip,
                entity_instance.entity_port,
                "/entitymanage/getpartialkey/",
                payload=payload,
            )
            if response.json()["status"] == "success":
                #增加实体信息
                acc.add_member(user_instance.user_fingerprint)
                #计算见证
                witness = acc.witness_generate_by_fingerprint(user_instance.user_fingerprint)
                if acc.verify_member(user_instance.user_fingerprint, witness):
                    print("验证见证成功")
                else:
                    print("验证见证失败")
                    aux = acc.remove_member(user_instance.user_fingerprint)
                    return JsonResponse({"status": "error", "message": "local验证见证失败"})
                print("acc:",acc.acc_cur)
                print("acc_sent:",hex2int(acc.get_acc_cur()))
                #发送aux给MS
                payload = {
                    "acc_data": {
                        "acc_cur": acc.get_acc_cur(),
                        "entity_pid": entity_instance.entity_pid,
                        "fingerprint": user_instance.user_fingerprint,
                        "witness": witness,
                    }
                }
                response = post_to_MS( "/entitymanage/update_accumulator/", payload)
                if response and response.json()["status"] == "success":
                    entity_instance.is_alive = True
                    user_instance.save()
                    print("用户信息保存成功")
                    entity_instance.save()
                    print("实体信息保存成功")
                    kgc_paramter_save()
                    return JsonResponse({"status": "success", "message": "用户添加成功！"})
                else:
                    aux = acc.remove_member(user_instance.user_fingerprint)
                    return JsonResponse(
                        {"status": "error", "message": response.json()["message"]}
                    )
            else:
                return JsonResponse(
                    {"status": "error", "message": response.json()["message"]}
                )

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

#更新累加器
@csrf_exempt
def update_accumulator(request):
    if request.method == "POST":
        data = json.loads(request.body)
        try:
            if data["action"] == "DEL":
                aux = hex2int(data["aux"])
                new_acc = gmpy2.powmod(acc.acc_cur, aux, acc.public_key)
                acc.acc_cur = new_acc
                pid = data["pid"]
                entity_instance = EntityTable.objects.get(entity_pid = pid)
                entity_instance.is_alive = False
                entity_instance.save()
                kgc_paramter_save()
                acc.save_accumlator_parameters()
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

def user_delete(request):
    if request.method == "POST":
        # json_data = request.get("delete_id")
        json_data = json.loads(request.body.decode("utf-8"))
        user_id = json_data["user_id"]
        user_instance = UserTable.objects.get(user_id=user_id)
        try:
            user_instance.delete()
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})


def user_update(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            print(json_data)
            user_id = json_data["user_id"]
            update_instance = UserTable.objects.get(user_id=user_id)
            if update_instance != None:
                if "user_fingerprint" in json_data:
                    update_instance.user_fingerprint = json_data["user_fingerprint"]
                if "user_phone" in json_data:
                    update_instance.user_phone = json_data["user_phone"]
                if "user_name" in json_data:
                    update_instance.user_name = json_data["user_name"]
                if "user_ip" in json_data:
                    update_instance.user_ip = json_data["user_ip"]

                update_instance.update_time = timezone.now()
                update_instance.save()
                return JsonResponse({"status": "success"})
            else:
                return JsonResponse({"status": "error", "message": "user not exist"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})


@csrf_exempt
def user_info(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data)
            user_id = json_data["user_id"]
            print(user_id)
            user_instance = ManagerTable.objects.get(manager_id=user_id)
            if user_instance == None:
                return JsonResponse({"status": "error", "message": "user not exist"})
            payload = {
                    "roles": ["admin"],
                    "introduction": "I am a super administrator",
                    "avatar": "https://upload.shejihz.com/2019/03/fe2ec2e7ed7f6795b46b793d93c99b7e.jpg",
                    "name": "管理员",
            }
            return JsonResponse({"status": "success", "data": payload})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})


def logout(request):
    if request.method == "POST":
        return JsonResponse({"status": "success"})


def user_query_all(request):
    if request.method == "POST":
        try:
            json_data = request.body.decode("utf-8")
            json_data = json.loads(json_data)
            page = json_data["page"]
            limit = json_data["limit"]
            query_instance = UserTable.objects.all()
            length = query_instance.count()
            if length < page * limit:
                send_instance = query_instance[(page - 1) * limit : length]
            else:
                send_instance = query_instance[(page - 1) * limit : page * limit]

            data = {
                "num": send_instance.count(),
                "data": [temp.get_data() for temp in send_instance],
            }
            return JsonResponse({"status": "success", "message": data})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})


def user_query_by_id(request):
    if request.method == "POST":
        try:
            json_data = request.POST.get("query_data")
            json_data = json.loads(json_data)
            user_id = json_data["user_id"]
            query_instance = UserTable.objects.filter(user_id=user_id)
            data = query_instance.get_data()
            return JsonResponse({"status": "success", "message": data})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

def post_to_PE(entity_ip: str, entity_port: int, path: str, payload: dict):
    header = {"content-type": "application/json", "Connection": "close"}
    url = "http://" + entity_ip + ":" + str(entity_port) + path
    data = json.dumps(payload)
    try:
        res = requests.post(url, data=data, headers=header)
        print(res.status_code)
        return res
    except Exception as e:
        entity_instance = EntityTable.objects.get(entity_ip=entity_ip)
        entity_instance.is_alive = False
        entity_instance.save()
        print(e)
        return None

def post_to_MS(path: str, payload: dict):
    header = {"content-type": "application/json", "Connection": "close"}
    url = "http://192.168.3.17:7997" + path
    data = json.dumps(payload)
    try:
        res = requests.post(url, data=data, headers=header)
        print(res.status_code)
        return res
    except Exception as e:
        print(e)
        return None
