from django.urls import path
from . import views

'''path("user-query-all/", views.user_query_all, name="user-query"),'''
urlpatterns = [
    path("delete-user/", views.user_delete, name="delete-user"),
    path("user-update/", views.user_update, name="user-update"),
    path("get-user/", views.user_query_by_id, name="get-user"),
    path("user-login/", views.user_login, name="user-login"),
    path("user-info/", views.user_info, name="user-info"),
    path("user-logout/", views.logout, name="logout"),
    path("user-add/", views.user_add, name="user-add"),
    path("update_accumulator/", views.update_accumulator, name="update_accumulator"),
    path("query-user-all/", views.user_query_all, name="query-user-all"),
]
