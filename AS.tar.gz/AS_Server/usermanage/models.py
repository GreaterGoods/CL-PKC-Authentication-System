from django.db import models


# Create your models here.
class ManagerTable(models.Model):
    manager_id = models.CharField(
        max_length=32, primary_key=True, verbose_name="manager id"
    )
    manager_name = models.CharField(max_length=20, verbose_name="manager name")
    manager_pwd = models.CharField(max_length=20, verbose_name="manager password")
    manager_phone = models.CharField(
        max_length=11, verbose_name="manager phone", null=True
    )
    manager_email = models.EmailField(verbose_name="manager email", null=True)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")
    update_time = models.DateTimeField(auto_now=True, verbose_name="update time")
    def get_data(self):
        return {
            "manager_id": self.manager_id,
            "manager_name": self.manager_name,
            "manager_pwd": self.manager_pwd,
            "manager_phone": self.manager_phone,
            "manager_email": self.manager_email,
            "create_time": self.create_time,
            "update_time": self.update_time,
        }

class UserTable(models.Model):
    user_id = models.CharField(max_length=32, primary_key=True, verbose_name="user id")
    user_name = models.CharField(max_length=20, verbose_name="user name")
    user_phone = models.CharField(max_length=11, verbose_name="user phone", null=True)
    user_fingerprint = models.TextField(verbose_name="user fingerprint")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")
    update_time = models.DateTimeField(auto_now=True, verbose_name="update time")

    def get_data(self):
        return {
            "user_id": self.user_id,
            "user_name": self.user_name,
            "user_phone": self.user_phone,
            "user_fingerprint": self.user_fingerprint,
            "create_time": self.create_time,
            "update_time": self.update_time,
        }
