from fastecdsa import curve, keys, point


class KGC:
    """KGC"""

    def __init__(self, ec_curve=curve.secp256k1):
        self.ec_curve = ec_curve
        self.s = None
        self.Ppub = None

    def set_up(self) -> None:
        self.s = keys.gen_private_key(self.ec_curve)
        self.Ppub = keys.get_public_key(self.s, self.ec_curve)

    def get_Ppub(self) -> str:
        return point2hex(self.Ppub)

    def get_s(self) -> str:
        return int2hex(self.s)

    def get_q(self) -> str:
        return int2hex(self.ec_curve.q)
    
    def get_P(self) -> str:
        return point2hex(self.ec_curve.G)
    
def int2hex(num: int) -> str:
    return hex(num)[2:].lower()

def point2hex(p: point.Point) -> str:
    """将椭圆曲线点序列化为 x|y 格式的十六进制字符串"""
    x_hex = int2hex(p.x)
    y_hex = int2hex(p.y)
    return f"{x_hex}|{y_hex}"

def hex2point(hex_str: str, curve=curve.secp256k1) -> point.Point:
    """从 x|y 格式的字符串恢复椭圆曲线点"""
    try:
        x_hex, y_hex = hex_str.split("|")
        x = int(x_hex, 16)
        y = int(y_hex, 16)
        p = point.Point(x, y, curve)
        if not curve.is_point_on_curve((x,y)):
            raise ValueError("点不在曲线上")
        return p
    except Exception as e:
        raise ValueError(f"无效的点格式: {e}")

if __name__ == "__main__":
    kgc = KGC()
    kgc.set_up()
    print(kgc.get_s())
    print(kgc.get_Ppub())
    print(kgc.get_q())
    print(kgc.get_P())

'''sql初始数据
INSERT INTO `entitymanage_kgcparamtertable` VALUES ('kgc_id','57b831ef836d237bbe55065fd97a21a58c82789810a931d4023a212c6e1a2df6','79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798|483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8','93b07eb082a7c58a1474302894ca31880d02a9ae7adbe102bcc25a58edc4e2e5|e28beb63378a2d4b8e2314b5733e52db5991a92ddf8acd4ff9b0a543ac41dbfd','fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141','97ef1f09dcc6e81e2c08f3c96f04710fe1d05b39ac00e6fc190de20293c7ee01','a775863f0ad44ca20035dbc8bee624ec9d65415f670e0a7b501bffb6bb298c064d977c6f3a43728ca6a4eca0c35cf0a3957c007de7b601e4302738a734c3bd43','97ef1f09dcc6e81e2c08f3c96f04710fe1d05b39ac00e6fc190de20293c7ee01','f04fccdf714e91d01d7d87fbb12c8826ca0aad405aeab51f72c91dbcedbd5991','b2642d67ff49bb64d5de352ddf412a0681495550ad73799772de8648ddc4df93')
'''