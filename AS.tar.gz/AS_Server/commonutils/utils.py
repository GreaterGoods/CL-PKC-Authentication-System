from cryptography.hazmat.primitives import hashes
from fastecdsa import point, keys
from gmpy2 import next_prime
from .kgc  import *
import secrets
import time
import hashlib

def get_prime_fingerprint(raw: str) -> int:
    # 先对原始数据做 hash，再取下一个素数
    h = int.from_bytes(hashlib.sha256(raw.encode()).digest(), 'big')
    return int(next_prime(h))

### 计算PID ###
def calculate_pid(Rid: str, timestamp: str,r:int,Ppub:str) -> str:
    """计算pid"""
    Ppub = hex2point(Ppub)
    rPpub = r*Ppub
    #让rPpub和timestamp拼接并进行hash   
    #H(riPpub,Ti)
    hash_result = hash_ec_point_and_time(rPpub, timestamp)
    #PIDi=RIDi ⊕H(riPpub,Ti)
    pid = xor_hex_strings(Rid, hash_result)
    return pid

def hash_ec_point_and_time(ec_point: point.Point, timestamp: str) -> bytes:
    # 将椭圆曲线点坐标序列化为字节（示例：拼接 x 和 y 的十六进制）
    x_bytes = hex(ec_point.x).encode()
    y_bytes = hex(ec_point.y).encode()
    time_bytes = timestamp.encode()
    # 拼接并哈希
    combined = f"{x_bytes.hex()}{y_bytes.hex()}{time_bytes}".encode()
    #使用MD5进行哈希
    digest = hashes.Hash(hashes.MD5())
    digest.update(combined)
    return digest.finalize()

def xor_hex_strings(a: str, b: bytes) -> str:
    # 将 RID转换为字节（假设 RID是十六进制字符串）
    rid_bytes = bytes.fromhex(a)
    # 异或操作
    xor_bytes = bytes(x ^ y for x, y in zip(rid_bytes, b))
    return xor_bytes.hex()

### 计算中间值，D=(d,R)即为部分密钥 ###
def PartialKeyGen(pid: str, r: int, R:point.Point, P: point.Point, Ppub: point.Point ,q:int,s:int) -> int:
    #h1i = H1(IDi,Ri,Ppub)
    combined = f"1{pid}{R.x}{R.y}{Ppub.x}{Ppub.y}"
    digest = hashes.Hash(hashes.MD5())
    digest.update(combined.encode())
    h1 = int.from_bytes(digest.finalize(), byteorder='big')
    #di = ri + s*h1i(mod q)
    d = (r + s * h1) % q
    return d



def calculate_str_hash(std: str) -> str:
    tmp_hash = hashes.Hash(hashes.MD5())
    tmp_hash.update(std.encode())
    return tmp_hash.finalize().hex()


def hex2int(hex: str) -> int:
    """conver hex string to int"""
    return int(hex, 16)


def int2hex(num: int) -> str:
    """conver int to hex string"""
    return hex(num)[2:].lower()


def get_bites(num: int, bits: int) -> str:
    """get bits of num"""
    return bin(num)[2:].zfill(bits)


def get_bits_length(num: int) -> int:
    """get bits length of num"""
    return len(get_bites(num, 128))


def point2hex(p: point.Point) -> str:
    """将椭圆曲线点序列化为 x|y 格式的十六进制字符串"""
    x_hex = int2hex(p.x)
    y_hex = int2hex(p.y)
    return f"{x_hex}|{y_hex}"

def hex2point(hex_str: str, curve=curve.secp256k1) -> point.Point:
    """从 x|y 格式的字符串恢复椭圆曲线点"""
    try:
        x_hex, y_hex = hex_str.split("|")
        x = int(x_hex, 16)
        y = int(y_hex, 16)
        p = point.Point(x, y, curve)
        if not curve.is_point_on_curve((x,y)):
            raise ValueError("点不在曲线上")
        return p
    except Exception as e:
        raise ValueError(f"无效的点格式: {e}")


def get_time_stamp() -> str:
    """get the current time stamp"""
    return str(int(time.time())+86400)#默认一天有效期


def get_time_point() -> float:
    """get time point"""
    return time.perf_counter()


def get_duration(start: float, end: float) -> float:#经历的时间差
    """
    Calculate the duration between two time points in milliseconds.

    Parameters:
    start_time (float): The start time in seconds.
    end_time (float): The end time in seconds.

    Returns:
    float: The duration between start_time and end_time in seconds.
    """

    return end - start


if __name__ == "__main__":
    import os

    start = get_time_point()
    timelimit=get_time_stamp()
    print(os.listdir())
    print(get_duration(start, get_time_point()))
    print(secrets.token_hex(16))
    print(calculate_pid("bcd50201d588932dfc271f0489bbf823", timelimit))

