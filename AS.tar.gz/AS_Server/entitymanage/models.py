from django.db import models


# Create your models here.
class EntityTable(models.Model):
    entity_index = models.AutoField(primary_key=True, verbose_name="entity index")
    entity_pid = models.CharField(max_length=32, verbose_name="entity pid")
    user_id = models.CharField(max_length=32, verbose_name="user id")
    entity_partialkey = models.TextField(verbose_name="entity partial key", null=True)
    entity_port = models.IntegerField(verbose_name="entity port")
    entity_ip = models.GenericIPAddressField(verbose_name="entity ip")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="create time")
    update_time = models.DateTimeField(auto_now=True, verbose_name="update time")
    is_alive = models.BooleanField(default=False, verbose_name="entity alive")

    def get_data(self):
        return {
            "entity_pid": self.entity_pid,
            "user_id": self.user_id,
            "entity_partialkey": self.entity_partialkey,
            "entity_ip": self.entity_ip,
            "entity_port":self.entity_port,
            "is_alive": self.is_alive,
            "create_time": self.create_time,
            "update_time": self.update_time,
        }



class KGCParamterTable(models.Model):
    kgc_id = models.CharField(primary_key=True, max_length=32, verbose_name="kgc id")
    kgc_s = models.TextField(verbose_name="kgc s")
    kgc_P = models.TextField(verbose_name="kgc P")
    kgc_Ppub = models.TextField(verbose_name="kgc Ppub")
    kgc_q = models.TextField(verbose_name="kgc q")
    kgc_acc_G = models.TextField(verbose_name="kgc acc G")#随机生成元
    kgc_acc_publickey = models.TextField(verbose_name="kgc acc public key")#p*q
    kgc_acc_cur = models.TextField(verbose_name="kgc acc cur")#累加值
    kgc_acc_serectkey0 = models.TextField(verbose_name="kgc acc serect key 0")#p
    kgc_acc_serectkey1 = models.TextField(verbose_name="kgc acc serect key 1")#q
