from django.http import HttpResponse, JsonResponse
from django.middleware.csrf import get_token
from commonutils import utils
from commonutils import accumulator
from commonutils import kgc
from .models import *
from usermanage.models import UserTable
import json, datetime, os
from fastecdsa import keys
import requests
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
acc = accumulator.Accumulator()
kgc = kgc.KGC()
# if os.path.exists("accumulator.json"):
#     acc.setup_from_file("accumulator.json")
# get calculated pids
temp_params = KGCParamterTable.objects.get(kgc_id="kgc_id")

acc.public_key = utils.hex2int(temp_params.kgc_acc_publickey)
acc.G = utils.hex2int(temp_params.kgc_acc_G)
acc.serect_key = (
    utils.hex2int(temp_params.kgc_acc_serectkey0),
    utils.hex2int(temp_params.kgc_acc_serectkey1),
)
acc.acc_cur = utils.hex2int(temp_params.kgc_acc_cur)
kgc.s = utils.hex2int(temp_params.kgc_s)
kgc.Ppub = keys.get_public_key(kgc.s, kgc.ec_curve)


# kgc初始化
def kgc_paramter_init(request):
    if request.method == "POST":
        try:
            kgc.set_up()
            acc.setup()
            kgc_instance = KGCParamterTable.objects.filter(kgc_id="kgc_id")
            kgc_instance.kgc_s = kgc.get_s()
            kgc_instance.kgc_Ppub = kgc.get_Ppub()
            kgc_instance.kgc_q = kgc.get_q()
            kgc_instance.kgc_acc_G = acc.get_G()
            kgc_instance.kgc_acc_publickey = acc.get_publickey()
            kgc_instance.kgc_acc_cur = acc.get_acc_cur()
            kgc_instance.kgc_acc_serectkey0 = acc.get_serect_key_0()
            kgc_instance.kgc_acc_serectkey1 = acc.get_serect_key_1()
            kgc_instance.save()
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})


def kgc_paramter_save():
    kgc_instance = KGCParamterTable.objects.get(kgc_id="kgc_id")
    kgc_instance.kgc_s = kgc.get_s()
    kgc_instance.kgc_Ppub = kgc.get_Ppub()
    kgc_instance.kgc_q = kgc.get_q()
    kgc_instance.kgc_acc_G = acc.get_G()
    kgc_instance.kgc_acc_publickey = acc.get_publickey()
    kgc_instance.kgc_acc_cur = acc.get_acc_cur()
    kgc_instance.kgc_acc_serectkey0 = acc.get_serect_key_0()
    kgc_instance.kgc_acc_serectkey1 = acc.get_serect_key_1()
    kgc_instance.save()


def entity_query_alive_by_uid(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            query_instance = EntityTable.objects.filter(
                is_alive=True, user_id=json_data["user_id"]
            )
            data = {
                "num": query_instance.count(),
                "data": [temp.get_data() for temp in query_instance],
            }
            return JsonResponse({"status": "success", "message": data})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})


def entity_query_alive(request):
    """
    return alive nodes
    """
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            page = json_data["page"]
            limit = json_data["limit"]
            query_instance = EntityTable.objects.filter(is_alive=True)
            length = query_instance.count()
            if length < page * limit:
                send_instance = query_instance[(page - 1) * limit : length]
            else:
                send_instance = query_instance[(page - 1) * limit : page * limit]
            data = {
                "num": send_instance.count(),
                "data": [temp.get_data() for temp in send_instance],
            }
            return JsonResponse({"status": "success", "message": data})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
'''
# 发送公共参数
def send_public_parameter(request):
    if request.method == "POST":
        node_entity = NodeTable.objects.get(node_ip=request.META.get("REMOTE_ADDR"))
        if node_entity == None:
            return JsonResponse({"status": "error", "message": "node not exists"})
        data = {
            "kgc_id": "kgc_id",
            "acc_publickey": acc.get_publickey(),
            "acc_cur": acc.get_acc_cur(),
            "kgc_q": kgc.get_q(),
            "kgc_Ppub": kgc.get_Ppub(),
        }
        node_entity.node_is_alive = True
        node_entity.save()
        return JsonResponse({"status": "success", "message": data})
'''

@csrf_exempt
def entity_query_pid(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            entity_pid = json_data["entity_pid"]
            query_instance = EntityTable.objects.get(entity_pid=entity_pid)
            data = query_instance.get_data()
            return JsonResponse({"status": "success", "message": data})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})


def entity_query_all(request):
    if request.method == "POST":
        try:
            json_data = json.loads(request.body.decode("utf-8"))
            page = json_data["page"]
            limit = json_data["limit"]
            query_instance = EntityTable.objects.all()
            length = query_instance.count()
            if length < page * limit:
                send_instance = query_instance[(page - 1) * limit : length]
            else:
                send_instance = query_instance[(page - 1) * limit : page * limit]
            data = {
                "num": send_instance.count(),
                "data": [temp.get_data() for temp in send_instance],
            }
            return JsonResponse({"status": "success", "message": data})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})




def post_to_ap(node_ip: str, node_port: int, path: str, payload: dict):
    header = {"content-type": "application/json", "Connection": "close"}
    url = "http://" + node_ip + ":" + str(node_port) + path
    data = json.dumps(payload)
    try:
        res = requests.post(url, data=data, headers=header)
        print(res.status_code)
        return res
    except Exception as e:
        print(e)
        return None

