from django.urls import path
from . import views

urlpatterns = [
    path("entity-query-alive/", views.entity_query_alive, name="entity-query-alive"),
    path("query-entity/", views.entity_query_pid, name="entity-query"),
    path("query-entity-all/", views.entity_query_all, name="entity-query-all"),
]
